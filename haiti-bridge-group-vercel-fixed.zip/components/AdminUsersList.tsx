import React, { useState, useEffect } from "react";
import { useAdminUsers, useAdminUpdateUser } from "../helpers/useAdmin";
import { useDebounce } from "../helpers/useDebounce";
import { UserRole, VerificationStatus } from "../helpers/schema";
import { Input } from "./Input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./Select";
import { Badge } from "./Badge";
import { Button } from "./Button";
import { Avatar, AvatarFallback, AvatarImage } from "./Avatar";
import { Skeleton } from "./Skeleton";
import { Pagination, PaginationContent, PaginationItem, PaginationNext, PaginationPrevious } from "./Pagination";
import { Search } from "lucide-react";
import { toast } from "sonner";
import styles from "./AdminUsersList.module.css";

export const AdminUsersList = () => {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState<UserRole | "_empty">("_empty");
  const [statusFilter, setStatusFilter] = useState<VerificationStatus | "_empty">("_empty");
  
  const debouncedSearch = useDebounce(search, 500);

  // Reset page when filters change
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, roleFilter, statusFilter]);

  const { data, isLoading } = useAdminUsers({
    page,
    limit: 20,
    search: debouncedSearch || undefined,
    role: roleFilter === "_empty" ? undefined : roleFilter,
    verificationStatus: statusFilter === "_empty" ? undefined : statusFilter,
  });

  const { mutate: updateUser, isPending: isUpdating } = useAdminUpdateUser();

  const handleRoleChange = (userId: number, newRole: UserRole) => {
    updateUser(
      { userId, role: newRole },
      {
        onSuccess: () => toast.success("Rôle mis à jour avec succès"),
        onError: (err) => toast.error(err instanceof Error ? err.message : "Erreur lors de la mise à jour"),
      }
    );
  };

  const handleVerification = (userId: number, status: VerificationStatus) => {
    updateUser(
      { userId, verificationStatus: status },
      {
        onSuccess: () => toast.success("Statut de vérification mis à jour"),
        onError: (err) => toast.error(err instanceof Error ? err.message : "Erreur lors de la mise à jour"),
      }
    );
  };

  const formatDate = (dateStr: string | Date | null) => {
    if (!dateStr) return "-";
    return new Intl.DateTimeFormat("fr-HT", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(dateStr));
  };

  return (
    <div className={styles.container}>
      <div className={styles.topBar}>
        <div className={styles.searchContainer}>
          <Search className={styles.searchIcon} size={18} />
          <Input
            className={styles.searchInput}
            placeholder="Rechercher par nom ou email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className={styles.filters}>
          <Select value={roleFilter} onValueChange={(val) => setRoleFilter(val as any)}>
            <SelectTrigger style={{ width: "160px" }}>
              <SelectValue placeholder="Rôle" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="_empty">Tous les rôles</SelectItem>
              <SelectItem value="admin">Admin</SelectItem>
              <SelectItem value="agent">Agent</SelectItem>
              <SelectItem value="user">Utilisateur</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={statusFilter} onValueChange={(val) => setStatusFilter(val as any)}>
            <SelectTrigger style={{ width: "180px" }}>
              <SelectValue placeholder="Statut Vérif." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="_empty">Tous les statuts</SelectItem>
              <SelectItem value="verified">Vérifié</SelectItem>
              <SelectItem value="pending">En attente</SelectItem>
              <SelectItem value="rejected">Rejeté</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Utilisateur</th>
              <th>Rôle</th>
              <th>Vérification</th>
              <th>Inscription</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  <td>
                    <div className={styles.userInfo}>
                      <Skeleton style={{ width: "2.5rem", height: "2.5rem", borderRadius: "50%" }} />
                      <div>
                        <Skeleton style={{ width: "120px", height: "1rem", marginBottom: "0.25rem" }} />
                        <Skeleton style={{ width: "150px", height: "0.875rem" }} />
                      </div>
                    </div>
                  </td>
                  <td><Skeleton style={{ width: "80px", height: "1.5rem", borderRadius: "1rem" }} /></td>
                  <td><Skeleton style={{ width: "80px", height: "1.5rem", borderRadius: "1rem" }} /></td>
                  <td><Skeleton style={{ width: "100px", height: "1rem" }} /></td>
                  <td><Skeleton style={{ width: "120px", height: "2rem" }} /></td>
                </tr>
              ))
            ) : data?.users.length === 0 ? (
              <tr>
                <td colSpan={5} className={styles.emptyState}>
                  Aucun utilisateur trouvé.
                </td>
              </tr>
            ) : (
              data?.users.map((user) => (
                <tr key={user.id}>
                  <td>
                    <div className={styles.userInfo}>
                      <Avatar>
                        {user.avatarUrl && <AvatarImage src={user.avatarUrl} alt={user.displayName} />}
                        <AvatarFallback>{user.displayName.substring(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className={styles.userName}>{user.displayName}</div>
                        <div className={styles.userEmail}>{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <Select 
                      value={user.role} 
                      onValueChange={(val) => handleRoleChange(user.id, val as UserRole)}
                      disabled={isUpdating}
                    >
                      <SelectTrigger className={styles.inlineSelect}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="agent">Agent</SelectItem>
                        <SelectItem value="user">Utilisateur</SelectItem>
                      </SelectContent>
                    </Select>
                  </td>
                  <td>
                    {user.verificationStatus === 'verified' && <Badge variant="success">Vérifié</Badge>}
                    {user.verificationStatus === 'pending' && <Badge variant="warning">En attente</Badge>}
                    {user.verificationStatus === 'rejected' && <Badge variant="destructive">Rejeté</Badge>}
                    {!user.verificationStatus && <span className={styles.emptyDash}>-</span>}
                  </td>
                  <td>{formatDate(user.createdAt)}</td>
                  <td>
                    <div className={styles.actions}>
                      {user.role === 'agent' && user.verificationStatus === 'pending' ? (
                        <>
                          <Button 
                            size="sm" 
                            className={styles.successButton} 
                            onClick={() => handleVerification(user.id, 'verified')}
                            disabled={isUpdating}
                          >
                            Approuver
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive" 
                            onClick={() => handleVerification(user.id, 'rejected')}
                            disabled={isUpdating}
                          >
                            Rejeter
                          </Button>
                        </>
                      ) : (
                        <span className={styles.emptyDash}>-</span>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {data && data.totalPages > 1 && (
        <div className={styles.paginationContainer}>
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious 
                  href="#" 
                  onClick={(e) => { e.preventDefault(); setPage((p) => Math.max(1, p - 1)); }} 
                  className={page === 1 ? styles.disabledPagination : ""}
                />
              </PaginationItem>
              <PaginationItem>
                <span className={styles.pageText}>Page {page} sur {data.totalPages}</span>
              </PaginationItem>
              <PaginationItem>
                <PaginationNext 
                  href="#" 
                  onClick={(e) => { e.preventDefault(); setPage((p) => Math.min(data.totalPages, p + 1)); }}
                  className={page >= data.totalPages ? styles.disabledPagination : ""}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}
    </div>
  );
};