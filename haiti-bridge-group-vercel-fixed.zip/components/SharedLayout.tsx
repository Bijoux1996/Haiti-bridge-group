import React from "react";
import { Link } from "react-router-dom";
import { Button } from "./Button";
import { useAuth } from "../helpers/useAuth";
import { MapPin, Phone, Mail, Heart } from "lucide-react";
import styles from "./SharedLayout.module.css";

export const SharedLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { authState, logout } = useAuth();

  return (
    <div className={styles.layout}>
      <header className={styles.header}>
        <div className={styles.headerContent}>
          <Link to="/" className={styles.logo}>
            Haiti<span>Bridge</span> Group
          </Link>
          <nav className={styles.nav}>
            <Link to="/properties?category=house_sale" className={styles.navLink}>Acheter</Link>
            <Link to="/properties?category=house_rent" className={styles.navLink}>Louer</Link>
            <Link to="/properties?category=land_sale" className={styles.navLink}>Terrain</Link>
            <Link to="/properties?category=commercial" className={styles.navLink}>Commercial</Link>
            <Link to="/pricing" className={styles.navLink}>Tarifs</Link>
            {authState.type === "authenticated" && (
              <Link to="/favorites" className={`${styles.navLink} ${styles.navLinkIcon}`}>
                <Heart size={16} />
                Favoris
              </Link>
            )}
            {authState.type === "authenticated" && (authState.user.role === "agent" || authState.user.role === "admin") && (
              <Link to="/dashboard" className={styles.navLink}>Tableau de Bord</Link>
            )}
            {authState.type === "authenticated" && authState.user.role === "admin" && (
              <Link to="/admin" className={styles.navLink}>Administration</Link>
            )}
          </nav>
          <div className={styles.auth}>
            {authState.type === "authenticated" ? (
              <div className={styles.userMenu}>
                <span className={styles.userName}>{authState.user.displayName}</span>
                {(authState.user.role === "agent" || authState.user.role === "admin") && (
                  <Button variant="outline" size="sm" asChild className={styles.logoutBtn}>
                    <Link to="/dashboard">Tableau de Bord</Link>
                  </Button>
                )}
                {authState.user.role === "admin" && (
                  <Button variant="outline" size="sm" asChild className={styles.logoutBtn}>
                    <Link to="/admin">Administration</Link>
                  </Button>
                )}
                <Button variant="outline" size="sm" onClick={() => logout()} className={styles.logoutBtn}>Déconnexion</Button>
              </div>
            ) : authState.type !== "loading" ? (
              <Button asChild size="sm" className={styles.loginBtn}>
                <Link to="/login">Se Connecter</Link>
              </Button>
            ) : null}
          </div>
        </div>
      </header>
      
      <main className={styles.main}>{children}</main>
      
      <footer className={styles.footer}>
        <div className={styles.footerContent}>
          <div className={styles.footerBrand}>
            <Link to="/" className={styles.logoFooter}>
              Haiti<span>Bridge</span> Group
            </Link>
            <p className={styles.footerText}>
              La plateforme de référence pour l'immobilier en Haïti. Trouvez la maison de vos rêves en toute confiance.
            </p>
          </div>
          <div className={styles.footerLinks}>
            <h4 className={styles.footerHeading}>Contact</h4>
            <div className={styles.footerContactItem}><MapPin size={16} /> Port-au-Prince, Haïti</div>
            <div className={styles.footerContactItem}><Phone size={16} /> +509 3000-0000</div>
            <div className={styles.footerContactItem}><Mail size={16} /> contact@haitibridge.com</div>
          </div>
        </div>
        <div className={styles.footerBottom}>
          <p>© {new Date().getFullYear()} Haiti Bridge Group. Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  );
};