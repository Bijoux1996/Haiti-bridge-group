import React, { useState } from "react";
import { z } from "zod";
import { useNavigate } from "react-router-dom";
import {
  Form,
  FormControl,
  FormItem,
  FormLabel,
  FormMessage,
  useForm,
} from "./Form";
import { Input } from "./Input";
import { Button } from "./Button";
import { Spinner } from "./Spinner";
import {
  schema as loginSchema,
  postLogin,
} from "../endpoints/auth/login_with_password_POST.schema";
import { useAuth } from "../helpers/useAuth";
import { useForgotPasswordSms, useVerifySmsCode } from "../helpers/useAuthSms";
import { useResetPassword } from "../helpers/useResetPassword";
import styles from "./PasswordLoginForm.module.css";

export type LoginFormData = z.infer<typeof loginSchema>;

const forgotSmsSchema = z.object({
  phone: z.string().min(1, "Le numéro de téléphone est requis"),
});

const verifySmsSchema = z.object({
  code: z.string().length(6, "Le code doit comporter exactement 6 chiffres"),
});

const resetPasswordSchema = z.object({
  newPassword: z.string()
    .min(8, "Le mot de passe doit faire au moins 8 caractères")
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      "Le mot de passe doit contenir au moins une majuscule, une minuscule et un chiffre"
    ),
  confirmPassword: z.string(),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Les mots de passe ne correspondent pas",
  path: ["confirmPassword"],
});

interface PasswordLoginFormProps {
  className?: string;
}

export const PasswordLoginForm: React.FC<PasswordLoginFormProps> = ({
  className,
}) => {
  const [mode, setMode] = useState<"login" | "forgot" | "verify" | "reset">("login");
  const [phone, setPhone] = useState("");
  const [token, setToken] = useState("");

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [forgotError, setForgotError] = useState<string | null>(null);
  const [verifyError, setVerifyError] = useState<string | null>(null);
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetSuccess, setResetSuccess] = useState(false);

  const forgotMutation = useForgotPasswordSms();
  const verifyMutation = useVerifySmsCode();
  const resetMutation = useResetPassword();

  const { onLogin } = useAuth();
  const navigate = useNavigate();

  const loginForm = useForm({
    defaultValues: { email: "", password: "" },
    schema: loginSchema,
  });

  const forgotForm = useForm({
    defaultValues: { phone: "" },
    schema: forgotSmsSchema,
  });

  const verifyForm = useForm({
    defaultValues: { code: "" },
    schema: verifySmsSchema,
  });

  const resetForm = useForm({
    defaultValues: { newPassword: "", confirmPassword: "" },
    schema: resetPasswordSchema,
  });

  const handleLoginSubmit = async (data: LoginFormData) => {
    setError(null);
    setIsLoading(true);

    try {
      const result = await postLogin(data);
      onLogin(result.user);
      setTimeout(() => navigate("/"), 200);
    } catch (err) {
      console.error("Login error:", err);
      setError(
        err instanceof Error ? err.message : "Échec de connexion. Veuillez réessayer."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotSubmit = async (data: z.infer<typeof forgotSmsSchema>) => {
    setForgotError(null);
    try {
      await forgotMutation.mutateAsync({ phone: data.phone });
      setPhone(data.phone);
      setMode("verify");
    } catch (err) {
      console.error("Forgot password SMS error:", err);
      setForgotError(
        err instanceof Error ? err.message : "Une erreur s'est produite. Veuillez réessayer."
      );
    }
  };

  const handleVerifySubmit = async (data: z.infer<typeof verifySmsSchema>) => {
    setVerifyError(null);
    try {
      const result = await verifyMutation.mutateAsync({ phone, code: data.code });
      setToken(result.token);
      setMode("reset");
    } catch (err) {
      console.error("Verify SMS error:", err);
      setVerifyError(
        err instanceof Error ? err.message : "Code invalide. Veuillez réessayer."
      );
    }
  };

  const handleResetSubmit = async (data: z.infer<typeof resetPasswordSchema>) => {
    setResetError(null);
    try {
      await resetMutation.mutateAsync({ token, newPassword: data.newPassword });
      setResetSuccess(true);
    } catch (err) {
      console.error("Reset password error:", err);
      setResetError(
        err instanceof Error ? err.message : "Une erreur s'est produite. Veuillez réessayer."
      );
    }
  };

  const resetToLogin = () => {
    setMode("login");
    setPhone("");
    setToken("");
    setForgotError(null);
    setVerifyError(null);
    setResetError(null);
    setResetSuccess(false);
  };

  if (mode === "reset") {
    return (
      <Form {...resetForm}>
        <form
          onSubmit={resetForm.handleSubmit(handleResetSubmit)}
          className={`${styles.form} ${styles.forgotForm} ${className || ""}`}
        >
          {resetError && <div className={styles.errorMessage}>{resetError}</div>}
          {resetSuccess && (
            <div className={styles.successMessage}>
              Votre mot de passe a été réinitialisé avec succès.
            </div>
          )}

          {!resetSuccess && (
            <div className={styles.forgotHeader}>
              <p>Entrez votre nouveau mot de passe.</p>
            </div>
          )}

          {!resetSuccess && (
            <>
              <FormItem name="newPassword">
                <FormLabel>Nouveau mot de passe</FormLabel>
                <FormControl>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    disabled={resetMutation.isPending}
                    value={resetForm.values.newPassword}
                    onChange={(e) =>
                      resetForm.setValues((prev) => ({ ...prev, newPassword: e.target.value }))
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>

              <FormItem name="confirmPassword">
                <FormLabel>Confirmez le mot de passe</FormLabel>
                <FormControl>
                  <Input
                    type="password"
                    placeholder="••••••••"
                    disabled={resetMutation.isPending}
                    value={resetForm.values.confirmPassword}
                    onChange={(e) =>
                      resetForm.setValues((prev) => ({ ...prev, confirmPassword: e.target.value }))
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>

              <Button
                type="submit"
                disabled={resetMutation.isPending}
                className={styles.submitButton}
              >
                {resetMutation.isPending ? (
                  <span className={styles.loadingText}>
                    <Spinner className={styles.spinner} size="sm" />
                    Réinitialisation...
                  </span>
                ) : (
                  "Mettre à jour le mot de passe"
                )}
              </Button>
            </>
          )}

          <div className={styles.backToLoginWrapper}>
            <Button variant="link" onClick={resetToLogin} className={styles.textLink}>
              Retour à la connexion
            </Button>
          </div>
        </form>
      </Form>
    );
  }

  if (mode === "verify") {
    return (
      <Form {...verifyForm}>
        <form
          onSubmit={verifyForm.handleSubmit(handleVerifySubmit)}
          className={`${styles.form} ${styles.forgotForm} ${className || ""}`}
        >
          {verifyError && <div className={styles.errorMessage}>{verifyError}</div>}

          <div className={styles.forgotHeader}>
            <p>Un code a été envoyé au {phone}. Entrez-le ci-dessous.</p>
          </div>

          <FormItem name="code">
            <FormLabel>Code de vérification</FormLabel>
            <FormControl>
              <Input
                placeholder="000000"
                maxLength={6}
                className={styles.codeInput}
                disabled={verifyMutation.isPending}
                value={verifyForm.values.code}
                onChange={(e) =>
                  verifyForm.setValues((prev) => ({ ...prev, code: e.target.value }))
                }
              />
            </FormControl>
            <FormMessage />
          </FormItem>

          <Button
            type="submit"
            disabled={verifyMutation.isPending}
            className={styles.submitButton}
          >
            {verifyMutation.isPending ? (
              <span className={styles.loadingText}>
                <Spinner className={styles.spinner} size="sm" />
                Vérification...
              </span>
            ) : (
              "Vérifier le code"
            )}
          </Button>

          <div className={styles.resendWrapper}>
            <Button
              type="button"
              variant="outline"
              disabled={forgotMutation.isPending}
              onClick={() => handleForgotSubmit({ phone })}
              className={styles.submitButton}
            >
              {forgotMutation.isPending ? "Envoi..." : "Renvoyer le code"}
            </Button>
          </div>

          <div className={styles.backToLoginWrapper}>
            <Button variant="link" onClick={resetToLogin} className={styles.textLink}>
              Retour à la connexion
            </Button>
          </div>
        </form>
      </Form>
    );
  }

  if (mode === "forgot") {
    return (
      <Form {...forgotForm}>
        <form
          onSubmit={forgotForm.handleSubmit(handleForgotSubmit)}
          className={`${styles.form} ${styles.forgotForm} ${className || ""}`}
        >
          {forgotError && <div className={styles.errorMessage}>{forgotError}</div>}

          <div className={styles.forgotHeader}>
            <p>Entrez votre numéro de téléphone pour recevoir un code de réinitialisation par SMS.</p>
          </div>

          <FormItem name="phone">
            <FormLabel>Numéro de téléphone</FormLabel>
            <FormControl>
              <Input
                placeholder="+509 XXXX XXXX"
                type="tel"
                autoComplete="tel"
                disabled={forgotMutation.isPending}
                value={forgotForm.values.phone}
                onChange={(e) =>
                  forgotForm.setValues((prev) => ({ ...prev, phone: e.target.value }))
                }
              />
            </FormControl>
            <FormMessage />
          </FormItem>

          <Button
            type="submit"
            disabled={forgotMutation.isPending}
            className={styles.submitButton}
          >
            {forgotMutation.isPending ? (
              <span className={styles.loadingText}>
                <Spinner className={styles.spinner} size="sm" />
                Envoi en cours...
              </span>
            ) : (
              "Envoyer le code SMS"
            )}
          </Button>

          <div className={styles.backToLoginWrapper}>
            <Button variant="link" onClick={resetToLogin} className={styles.textLink}>
              Retour à la connexion
            </Button>
          </div>
        </form>
      </Form>
    );
  }

  return (
    <Form {...loginForm}>
      <form
        onSubmit={loginForm.handleSubmit(handleLoginSubmit)}
        className={`${styles.form} ${className || ""}`}
      >
        {error && <div className={styles.errorMessage}>{error}</div>}

        <FormItem name="email">
          <FormLabel>Adresse email</FormLabel>
          <FormControl>
            <Input
              placeholder="votre@email.com"
              type="email"
              autoComplete="email"
              disabled={isLoading}
              value={loginForm.values.email}
              onChange={(e) =>
                loginForm.setValues((prev) => ({ ...prev, email: e.target.value }))
              }
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <FormItem name="password">
          <div className={styles.passwordHeader}>
            <FormLabel>Mot de passe</FormLabel>
            <Button
              type="button"
              variant="link"
              onClick={() => setMode("forgot")}
              className={styles.textLink}
            >
              Mot de passe oublié ?
            </Button>
          </div>
          <FormControl>
            <Input
              type="password"
              placeholder="••••••••"
              autoComplete="current-password"
              disabled={isLoading}
              value={loginForm.values.password}
              onChange={(e) =>
                loginForm.setValues((prev) => ({
                  ...prev,
                  password: e.target.value,
                }))
              }
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <Button
          type="submit"
          disabled={isLoading}
          className={styles.submitButton}
        >
          {isLoading ? (
            <span className={styles.loadingText}>
              <Spinner className={styles.spinner} size="sm" />
              Connexion en cours...
            </span>
          ) : (
            "Se Connecter"
          )}
        </Button>
      </form>
    </Form>
  );
};