import React, { useState } from "react";
import { toast } from "sonner";
import {
  MapPin,
  User,
  Phone,
  Mail,
  Calendar as CalendarIcon,
  MessageSquare,
  CalendarX2,
} from "lucide-react";
import { useMyAppointments, useUpdateAppointment } from "../helpers/useAppointments";
import { AppointmentStatus } from "../helpers/schema";
import { Button } from "./Button";
import { Badge } from "./Badge";
import { Skeleton } from "./Skeleton";
import { Spinner } from "./Spinner";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "./Pagination";
import styles from "./DashboardAppointments.module.css";

interface DashboardAppointmentsProps {
  className?: string;
}

type FilterStatus = AppointmentStatus | "all";

const STATUS_LABELS: Record<AppointmentStatus, string> = {
  pending: "En attente",
  confirmed: "Confirmé",
  completed: "Terminé",
  cancelled: "Annulé",
};

const STATUS_VARIANTS: Record<AppointmentStatus, React.ComponentProps<typeof Badge>["variant"]> = {
  pending: "warning",
  confirmed: "success",
  completed: "primary",
  cancelled: "destructive",
};

export const DashboardAppointments: React.FC<DashboardAppointmentsProps> = ({
  className,
}) => {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState<FilterStatus>("all");
  const [updatingId, setUpdatingId] = useState<number | null>(null);

  const { data, isPending, isError, error } = useMyAppointments({
    page,
    limit: 10,
    status: statusFilter === "all" ? undefined : statusFilter,
  });

  const { mutateAsync: updateStatus } = useUpdateAppointment();

  const handleStatusUpdate = async (id: number, newStatus: "confirmed" | "cancelled" | "completed") => {
    try {
      setUpdatingId(id);
      await updateStatus({ appointmentId: id, status: newStatus });
      toast.success(`Statut mis à jour : ${STATUS_LABELS[newStatus]}`);
    } catch (err) {
      toast.error(
        err instanceof Error
          ? err.message
          : "Erreur lors de la mise à jour du statut"
      );
    } finally {
      setUpdatingId(null);
    }
  };

  const filters: { value: FilterStatus; label: string }[] = [
    { value: "all", label: "Tous" },
    { value: "pending", label: "En attente" },
    { value: "confirmed", label: "Confirmé" },
    { value: "completed", label: "Terminé" },
    { value: "cancelled", label: "Annulé" },
  ];

  return (
    <div className={`${styles.container} ${className || ""}`}>
      <div className={styles.header}>
        <div className={styles.filters}>
          {filters.map((filter) => (
            <Button
              key={filter.value}
              variant={statusFilter === filter.value ? "primary" : "outline"}
              size="sm"
              onClick={() => {
                setStatusFilter(filter.value);
                setPage(1);
              }}
              className={styles.filterBtn}
            >
              {filter.label}
            </Button>
          ))}
        </div>
      </div>

      {isError ? (
        <div className={styles.errorState}>
          <p>Erreur: {error instanceof Error ? error.message : "Erreur inconnue"}</p>
        </div>
      ) : isPending ? (
        <div className={styles.list}>
          {[1, 2, 3].map((i) => (
            <div key={i} className={styles.card}>
              <div className={styles.cardHeader}>
                <Skeleton className={styles.skeletonTitle} />
                <Skeleton className={styles.skeletonBadge} />
              </div>
              <div className={styles.cardBody}>
                <Skeleton className={styles.skeletonText} />
                <Skeleton className={styles.skeletonText} />
                <Skeleton className={styles.skeletonText} />
              </div>
            </div>
          ))}
        </div>
      ) : !data || data.appointments.length === 0 ? (
        <div className={styles.emptyState}>
          <CalendarX2 className={styles.emptyIcon} />
          <h3 className={styles.emptyTitle}>Aucun rendez-vous</h3>
          <p className={styles.emptyMessage}>
            Il n'y a aucun rendez-vous pour le moment dans cette catégorie.
          </p>
        </div>
      ) : (
        <>
          <div className={styles.list}>
            {data.appointments.map((appt) => (
              <div key={appt.id} className={styles.card}>
                <div className={styles.cardHeader}>
                  <div>
                    <h3 className={styles.propertyTitle}>{appt.propertyTitle}</h3>
                    <p className={styles.propertyCity}>
                      <MapPin className={styles.inlineIcon} /> {appt.propertyCity}
                    </p>
                  </div>
                  <Badge variant={STATUS_VARIANTS[appt.status as AppointmentStatus]}>
                    {STATUS_LABELS[appt.status as AppointmentStatus] || appt.status}
                  </Badge>
                </div>

                <div className={styles.cardBody}>
                  <div className={styles.clientInfo}>
                    <p>
                      <User className={styles.inlineIcon} /> {appt.clientName}
                    </p>
                    <p>
                      <Phone className={styles.inlineIcon} /> {appt.clientPhone}
                    </p>
                    {appt.clientEmail && (
                      <p>
                        <Mail className={styles.inlineIcon} /> {appt.clientEmail}
                      </p>
                    )}
                  </div>
                  
                  <div className={styles.dateTime}>
                    <p>
                      <CalendarIcon className={styles.inlineIcon} />{" "}
                      {new Intl.DateTimeFormat("fr-FR", {
                        dateStyle: "full",
                      }).format(new Date(appt.preferredDate))}
                      {" à "}
                      <strong>{appt.preferredTime}</strong>
                    </p>
                  </div>

                  {appt.message && (
                    <div className={styles.messageBox}>
                      <MessageSquare className={styles.inlineIcon} />
                      <p>{appt.message}</p>
                    </div>
                  )}
                </div>

                <div className={styles.cardFooter}>
                  {appt.status === "pending" && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        className={styles.actionConfirm}
                        onClick={() => handleStatusUpdate(appt.id, "confirmed")}
                        disabled={updatingId !== null}
                      >
                        {updatingId === appt.id ? <Spinner size="sm" /> : "Confirmer"}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className={styles.actionCancel}
                        onClick={() => handleStatusUpdate(appt.id, "cancelled")}
                        disabled={updatingId !== null}
                      >
                        Annuler
                      </Button>
                    </>
                  )}
                  {appt.status === "confirmed" && (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        className={styles.actionComplete}
                        onClick={() => handleStatusUpdate(appt.id, "completed")}
                        disabled={updatingId !== null}
                      >
                        {updatingId === appt.id ? <Spinner size="sm" /> : "Marquer terminé"}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className={styles.actionCancel}
                        onClick={() => handleStatusUpdate(appt.id, "cancelled")}
                        disabled={updatingId !== null}
                      >
                        Annuler
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>

          {data.totalPages > 1 && (
            <Pagination className={styles.pagination}>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.max(1, p - 1));
                    }}
                    aria-disabled={page === 1}
                    className={page === 1 ? styles.disabledPagination : ""}
                  />
                </PaginationItem>
                
                {Array.from({ length: data.totalPages }).map((_, i) => (
                  <PaginationItem key={i}>
                    <PaginationLink
                      href="#"
                      isActive={page === i + 1}
                      onClick={(e) => {
                        e.preventDefault();
                        setPage(i + 1);
                      }}
                    >
                      {i + 1}
                    </PaginationLink>
                  </PaginationItem>
                ))}

                <PaginationItem>
                  <PaginationNext
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.min(data.totalPages, p + 1));
                    }}
                    aria-disabled={page === data.totalPages}
                    className={page === data.totalPages ? styles.disabledPagination : ""}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}
    </div>
  );
};