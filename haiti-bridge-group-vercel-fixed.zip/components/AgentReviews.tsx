import React, { useState } from "react";
import { Star, StarHalf } from "lucide-react";
import { useAuth } from "../helpers/useAuth";
import {
  useAgentReviews,
  useCreateReview,
  useCheckReview,
} from "../helpers/useReviews";
import { Button } from "./Button";
import { Textarea } from "./Textarea";
import { Avatar, AvatarImage, AvatarFallback } from "./Avatar";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationPrevious,
  PaginationNext,
  PaginationEllipsis,
} from "./Pagination";
import { Skeleton } from "./Skeleton";
import styles from "./AgentReviews.module.css";

interface AgentReviewsProps {
  agentId: number;
  agentName: string;
  propertyId?: number;
  className?: string;
}

export const AgentReviews = ({
  agentId,
  agentName,
  propertyId,
  className,
}: AgentReviewsProps) => {
  const [page, setPage] = useState(1);
  const { authState } = useAuth();
  const limit = 5;

  const { data, isFetching } = useAgentReviews({ agentId, page, limit });

  const isUserAuthenticated = authState.type === "authenticated";
  const isAgentThemselves =
    isUserAuthenticated && authState.user.id === agentId;

  const { data: checkData, isFetching: checkLoading } = useCheckReview(
    { agentId, propertyId },
    { enabled: isUserAuthenticated && !isAgentThemselves }
  );

  const showForm =
    isUserAuthenticated &&
    !isAgentThemselves &&
    !checkLoading &&
    checkData?.hasReviewed === false;

  return (
    <div className={`${styles.container} ${className || ""}`}>
      <h2 className={styles.sectionTitle}>Avis sur {agentName}</h2>

      <div className={styles.topSection}>
        {isFetching && !data ? (
          <Skeleton className={styles.statsSkeleton} />
        ) : data && data.stats.totalReviews > 0 ? (
          <div className={styles.statsContainer}>
            <div className={styles.averageContainer}>
              <div className={styles.averageRating}>
                {data.stats.averageRating.toFixed(1)}
              </div>
              <div className={styles.averageStars}>
                <Stars rating={data.stats.averageRating} />
              </div>
              <div className={styles.totalReviews}>
                {data.stats.totalReviews} avis
              </div>
            </div>
            <div className={styles.distributionContainer}>
              {[5, 4, 3, 2, 1].map((star) => {
                const count =
                  data.stats.distribution[
                    star as keyof typeof data.stats.distribution
                  ] || 0;
                const percentage =
                  data.stats.totalReviews > 0
                    ? (count / data.stats.totalReviews) * 100
                    : 0;

                return (
                  <div key={star} className={styles.distributionRow}>
                    <div className={styles.distributionLabel}>{star}</div>
                    <div className={styles.progressTrack}>
                      <div
                        className={styles.progressFill}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <div className={styles.distributionCount}>{count}</div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className={styles.noReviewsStats}>
            Aucun avis pour le moment.
          </div>
        )}

        {showForm && (
          <div className={styles.formContainer}>
            <ReviewForm agentId={agentId} propertyId={propertyId} />
          </div>
        )}
      </div>

      <div className={styles.reviewsList}>
        {isFetching && !data ? (
          Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className={styles.reviewCardSkeleton} />
          ))
        ) : data && data.reviews.length > 0 ? (
          <>
            <div className={styles.reviewsGrid}>
              {data.reviews.map((review) => (
                <div key={review.id} className={styles.reviewCard}>
                  <div className={styles.reviewHeader}>
                    <Avatar className={styles.avatar}>
                      <AvatarImage
                        src={review.reviewerAvatar || undefined}
                        alt={review.reviewerName}
                      />
                      <AvatarFallback>
                        {review.reviewerName.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className={styles.reviewerInfo}>
                      <div className={styles.reviewerName}>
                        {review.reviewerName}
                      </div>
                      <div className={styles.reviewDate}>
                        {review.createdAt
                          ? new Intl.DateTimeFormat("fr-FR", {
                              dateStyle: "long",
                            }).format(new Date(review.createdAt))
                          : ""}
                      </div>
                    </div>
                  </div>
                  <div className={styles.reviewStars}>
                    <Stars rating={review.rating} />
                  </div>
                  {review.propertyTitle && (
                    <div className={styles.reviewProperty}>
                      Concernant: {review.propertyTitle}
                    </div>
                  )}
                  {review.comment && (
                    <p className={styles.reviewComment}>{review.comment}</p>
                  )}
                </div>
              ))}
            </div>

            {data.totalPages > 1 && (
              <Pagination className={styles.pagination}>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        if (page > 1) setPage(p => p - 1);
                      }}
                      aria-disabled={page === 1}
                      className={page === 1 ? styles.disabledPagination : ""}
                    />
                  </PaginationItem>
                  
                  {/* Simplified pagination for demo - can be expanded to full logic */}
                  <PaginationItem>
                    <span className={styles.pageIndicator}>
                      Page {page} sur {data.totalPages}
                    </span>
                  </PaginationItem>

                  <PaginationItem>
                    <PaginationNext
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        if (page < data.totalPages) setPage(p => p + 1);
                      }}
                      aria-disabled={page === data.totalPages}
                      className={page === data.totalPages ? styles.disabledPagination : ""}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            )}
          </>
        ) : (
          <div className={styles.emptyState}>
            Soyez le premier à laisser un avis pour cet agent !
          </div>
        )}
      </div>
    </div>
  );
};

// Sub-components

const Stars = ({ rating }: { rating: number }) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

  return (
    <div className={styles.starsWrapper}>
      {Array.from({ length: fullStars }).map((_, i) => (
        <Star key={`full-${i}`} className={styles.starFilled} size={16} />
      ))}
      {hasHalfStar && <StarHalf className={styles.starFilled} size={16} />}
      {Array.from({ length: emptyStars }).map((_, i) => (
        <Star key={`empty-${i}`} className={styles.starEmpty} size={16} />
      ))}
    </div>
  );
};

const ReviewForm = ({
  agentId,
  propertyId,
}: {
  agentId: number;
  propertyId?: number;
}) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const { mutate, isPending } = useCreateReview();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) return;

    mutate(
      { agentId, propertyId, rating, comment },
      {
        onSuccess: () => {
          setRating(0);
          setComment("");
        },
      }
    );
  };

  return (
    <form onSubmit={handleSubmit} className={styles.form}>
      <h3 className={styles.formTitle}>Laisser un avis</h3>
      <div className={styles.ratingInput}>
        <div className={styles.interactiveStars}>
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              className={styles.starButton}
              onClick={() => setRating(star)}
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(0)}
            >
              <Star
                size={24}
                className={
                  star <= (hoverRating || rating)
                    ? styles.starFilled
                    : styles.starEmpty
                }
              />
            </button>
          ))}
        </div>
        {rating === 0 && (
          <span className={styles.ratingHint}>Sélectionnez une note</span>
        )}
      </div>

      <Textarea
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Partagez votre expérience avec cet agent... (Optionnel)"
        className={styles.textarea}
        disabled={isPending}
      />

      <div className={styles.formActions}>
        <Button type="submit" disabled={rating === 0 || isPending}>
          {isPending ? "Publication..." : "Publier l'avis"}
        </Button>
      </div>
    </form>
  );
};