import React, { useState } from "react";
import styles from "./PropertyGallery.module.css";

export const PropertyGallery: React.FC<{ images: { id: number; imageUrl: string; isPrimary: boolean | null; }[] }> = ({ images }) => {
  const sortedImages = [...images].sort((a, b) => (a.isPrimary === b.isPrimary ? 0 : a.isPrimary ? -1 : 1));
  const [activeIndex, setActiveIndex] = useState(0);

  if (images.length === 0) return (
    <div className={styles.emptyGallery}>
      <p>Aucune image disponible</p>
    </div>
  );

  return (
    <div className={styles.gallery}>
      <div className={styles.mainImageContainer}>
        <img src={sortedImages[activeIndex].imageUrl} className={styles.mainImage} alt="Property main view" />
      </div>
      {sortedImages.length > 1 && (
        <div className={styles.thumbnailList}>
          {sortedImages.map((img, idx) => (
            <button 
              key={img.id} 
              className={`${styles.thumbnail} ${idx === activeIndex ? styles.active : ""}`} 
              onClick={() => setActiveIndex(idx)}
              aria-label={`View image ${idx + 1}`}
            >
              <img src={img.imageUrl} alt={`Thumbnail ${idx + 1}`} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};