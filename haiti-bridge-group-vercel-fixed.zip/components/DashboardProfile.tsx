import React, { useRef, useState } from "react";
import { useAuth } from "../helpers/useAuth";
import { useMyListings } from "../helpers/useAgentProperties";
import { Link } from "react-router-dom";
import { useWhatsAppAgentStats } from "../helpers/useWhatsApp";
import { Avatar, AvatarFallback, AvatarImage } from "./Avatar";
import { Mail, Building, Star, ShieldCheck, MessageCircle, Copy, Facebook, ExternalLink, Camera, Loader2 } from "lucide-react";
import { useUpdateAvatar } from "../helpers/useUpdateAvatar";
import { compressImage } from "../helpers/compressImage";
import { Badge } from "./Badge";
import { Button } from "./Button";
import { Input } from "./Input";
import { toast } from "sonner";
import styles from "./DashboardProfile.module.css";

export const DashboardProfile = () => {
  const { authState } = useAuth();
  const { data } = useMyListings();
  const { data: whatsappStats } = useWhatsAppAgentStats({ period: "month" });
  const { mutateAsync: updateAvatar } = useUpdateAvatar();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);

  if (authState.type !== "authenticated") return null;

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      const base64Image = await compressImage(file);
      await updateAvatar({ avatarUrl: base64Image });
    } catch (error) {
      console.error(error);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleEditClick = () => {
    fileInputRef.current?.click();
  };

  const user = authState.user;
  const properties = data?.properties || [];
  const featuredCount = properties.filter((p) => p.isFeatured).length;

  const initials = user.displayName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .substring(0, 2)
    .toUpperCase();

  const baseSlug = user.displayName
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
  
  const slug = `${baseSlug}-${user.id}`;
  const profileUrl = `https://www.haitibridgegroup.com/agent/${slug}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(profileUrl);
    toast.success("Lien copié !");
  };

  return (
    <div className={styles.container}>
      <div className={styles.profileCard}>
        <div className={styles.header}>
          <div className={styles.avatarWrapper}>
            <div className={styles.avatarContainer}>
              <Avatar className={styles.avatar}>
                <AvatarImage src={user.avatarUrl || ""} alt={user.displayName} />
                <AvatarFallback>{initials}</AvatarFallback>
              </Avatar>
              {isUploading && (
                <div className={styles.uploadOverlay}>
                  <Loader2 className={styles.spinner} size={24} />
                </div>
              )}
            </div>
            
            <div className={styles.verifiedBadge} title="Agent Vérifié">
              <ShieldCheck size={20} />
            </div>

            <button 
              className={styles.editButton} 
              onClick={handleEditClick}
              disabled={isUploading}
              aria-label="Modifier la photo de profil"
            >
              <Camera size={16} />
            </button>
            <input 
              type="file"
              accept="image/*"
              className={styles.hiddenInput}
              ref={fileInputRef}
              onChange={handleFileChange}
            />
          </div>

          <div className={styles.info}>
            <h2 className={styles.name}>{user.displayName}</h2>
            <div className={styles.roleRow}>
              <Badge variant="secondary" className={styles.roleBadge}>
                {user.role === "admin" ? "Administrateur" : "Agent Pro"}
              </Badge>
              <div className={styles.contactItem}>
                <Mail size={16} />
                <span>{user.email}</span>
              </div>
            </div>
          </div>
        </div>

        <div className={styles.shareSection}>
          <div className={styles.shareHeader}>
            <h3 className={styles.shareTitle}>Mon Lien Personnel</h3>
          </div>
          <div className={styles.linkRow}>
            <Input readOnly value={profileUrl} className={styles.linkInput} />
            <Button onClick={handleCopy} variant="secondary">
              Copier
            </Button>
          </div>
          <div className={styles.actionRow}>
            <Button asChild variant="outline">
              <a
                href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
                  profileUrl
                )}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Facebook size={16} /> Facebook
              </a>
            </Button>
            <Button asChild variant="outline">
              <a
                href={`https://wa.me/?text=${encodeURIComponent(
                  `Découvrez mon profil d'agent immobilier sur Haiti Bridge Group : ${profileUrl}`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle size={16} /> WhatsApp
              </a>
            </Button>
            <Button onClick={handleCopy} variant="outline">
              <Copy size={16} /> Copier le lien
            </Button>
            <Button asChild variant="outline">
              <Link to={`/agent/${slug}`}>
                <ExternalLink size={16} /> Voir mon profil
              </Link>
            </Button>
          </div>
        </div>

        <div className={styles.statsGrid}>
          <div className={styles.statCard}>
            <div className={styles.statIconWrapper}>
              <Building size={24} className={styles.statIconBlue} />
            </div>
            <div className={styles.statContent}>
              <div className={styles.statValue}>{properties.length}</div>
              <div className={styles.statLabel}>Propriétés totales</div>
            </div>
          </div>

          <div className={styles.statCard}>
            <div className={styles.statIconWrapper}>
              <Star size={24} className={styles.statIconGold} />
            </div>
            <div className={styles.statContent}>
              <div className={styles.statValue}>{featuredCount}</div>
              <div className={styles.statLabel}>Annonces en vedette</div>
            </div>
          </div>

          <div className={styles.statCard}>
            <div className={styles.statIconWrapper}>
              <MessageCircle size={24} className={styles.statIconGreen} />
            </div>
            <div className={styles.statContent}>
              <div className={styles.statValue}>{whatsappStats?.totalContacts ?? 0}</div>
              <div className={styles.statLabel}>Contacts WhatsApp (ce mois)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};