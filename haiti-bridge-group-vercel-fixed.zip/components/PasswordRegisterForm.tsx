import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
  useForm,
} from "./Form";
import { Input } from "./Input";
import { Button } from "./Button";
import { Spinner } from "./Spinner";
import { useAuth } from "../helpers/useAuth";
import {
  schema,
  postRegister,
} from "../endpoints/auth/register_with_password_POST.schema";
import styles from "./PasswordRegisterForm.module.css";

export type RegisterFormData = z.infer<typeof schema>;

interface PasswordRegisterFormProps {
  className?: string;
  defaultValues?: Partial<RegisterFormData>;
}

export const PasswordRegisterForm: React.FC<PasswordRegisterFormProps> = ({
  className,
  defaultValues,
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { onLogin } = useAuth();
  const navigate = useNavigate();

  const form = useForm({
    schema,
    defaultValues: defaultValues || {
      email: "",
      password: "",
      displayName: "",
      phone: "",
    },
  });

  const handleSubmit = async (data: z.infer<typeof schema>) => {
    setError(null);
    setIsLoading(true);

    try {
      const result = await postRegister(data);
      console.log("Registration successful for:", data.email);
      onLogin(result.user);
      navigate("/");
    } catch (err) {
      console.error("Registration error:", err);

      if (err instanceof Error) {
        const errorMessage = err.message;

        if (errorMessage.includes("Email already in use")) {
          setError(
            "Cet email est déjà enregistré. Veuillez vous connecter."
          );
        } else if (errorMessage.toLowerCase().includes("display name")) {
          setError("Veuillez fournir un nom d'affichage valide.");
        } else if (
          errorMessage.includes("display") ||
          errorMessage.includes("name")
        ) {
          setError("Vérifiez votre nom d'affichage : " + errorMessage);
        } else {
          setError(errorMessage || "L'inscription a échoué. Veuillez réessayer.");
        }
      } else {
        console.log("Unknown error type:", err);
        setError("L'inscription a échoué. Veuillez réessayer.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Form {...form}>
      {error && <div className={styles.errorMessage}>{error}</div>}
      <form
        onSubmit={form.handleSubmit((data) =>
          handleSubmit(data as z.infer<typeof schema>)
        )}
        className={`${styles.form} ${className || ""}`}
      >
        <FormItem name="email">
          <FormLabel>Adresse email</FormLabel>
          <FormControl>
            <Input
              placeholder="votre@email.com"
              value={form.values.email || ""}
              onChange={(e) =>
                form.setValues((prev: any) => ({
                  ...prev,
                  email: e.target.value,
                }))
              }
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <FormItem name="displayName">
          <FormLabel>Nom d'affichage</FormLabel>
          <FormControl>
            <Input
              id="register-display-name"
              placeholder="Votre nom"
              value={form.values.displayName || ""}
              onChange={(e) =>
                form.setValues((prev: any) => ({
                  ...prev,
                  displayName: e.target.value,
                }))
              }
            />
          </FormControl>
          <FormDescription>
            Espaces, emojis et caractères spéciaux sont autorisés
          </FormDescription>
          <FormMessage />
        </FormItem>

        <FormItem name="phone">
          <FormLabel>Numéro de téléphone</FormLabel>
          <FormControl>
            <Input
              type="tel"
              placeholder="+509 XXXX XXXX"
              value={form.values.phone || ""}
              onChange={(e) =>
                form.setValues((prev: any) => ({
                  ...prev,
                  phone: e.target.value,
                }))
              }
            />
          </FormControl>
          <FormDescription>
            Requis pour la récupération de mot de passe par SMS
          </FormDescription>
          <FormMessage />
        </FormItem>

        <FormItem name="password">
          <FormLabel>Mot de passe</FormLabel>
          <FormControl>
            <Input
              type="password"
              placeholder="••••••••"
              value={form.values.password || ""}
              onChange={(e) =>
                form.setValues((prev: any) => ({
                  ...prev,
                  password: e.target.value,
                }))
              }
            />
          </FormControl>
          <FormDescription>
            Au moins 8 caractères avec majuscule, minuscule et chiffre
          </FormDescription>
          <FormMessage />
        </FormItem>

        <Button
          type="submit"
          disabled={isLoading}
          className={styles.submitButton}
        >
          {isLoading ? (
            <>
              <Spinner size="sm" /> Création du compte...
            </>
          ) : (
            "Créer mon compte"
          )}
        </Button>
      </form>
    </Form>
  );
};
