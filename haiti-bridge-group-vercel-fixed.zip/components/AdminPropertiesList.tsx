import React, { useState, useEffect } from "react";
import { useAdminProperties, useAdminUpdateProperty } from "../helpers/useAdmin";
import { useDebounce } from "../helpers/useDebounce";
import { PropertyCategory } from "../helpers/schema";
import { postDeleteProperty } from "../endpoints/property/delete_POST.schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Input } from "./Input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./Select";
import { Button } from "./Button";
import { Skeleton } from "./Skeleton";
import { Pagination, PaginationContent, PaginationItem, PaginationNext, PaginationPrevious } from "./Pagination";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "./Dialog";
import { Search, Star, Trash, Building } from "lucide-react";
import { toast } from "sonner";
import styles from "./AdminPropertiesList.module.css";

const CATEGORY_LABELS: Record<string, string> = {
  house_sale: "Maison à vendre",
  house_rent: "Maison à louer",
  land_sale: "Terrain à vendre",
  apartment: "Appartement",
  commercial: "Commercial"
};

export const AdminPropertiesList = () => {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<PropertyCategory | "_empty">("_empty");
  const [propertyToDelete, setPropertyToDelete] = useState<number | null>(null);
  
  const debouncedSearch = useDebounce(search, 500);

  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, categoryFilter]);

  const { data, isLoading } = useAdminProperties({
    page,
    limit: 15,
    search: debouncedSearch || undefined,
    category: categoryFilter === "_empty" ? undefined : categoryFilter,
  });

  const { mutate: updateProperty, isPending: isUpdating } = useAdminUpdateProperty();

  const deleteMutation = useMutation({
    mutationFn: (id: number) => postDeleteProperty({ id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "properties"] });
      toast.success("Propriété supprimée avec succès");
      setPropertyToDelete(null);
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "Erreur de suppression");
    }
  });

  const handleToggleFeatured = (propertyId: number, currentFeatured: boolean) => {
    updateProperty(
      { propertyId, isFeatured: !currentFeatured },
      {
        onSuccess: () => toast.success("Statut de mise en vedette mis à jour"),
        onError: (err) => toast.error(err instanceof Error ? err.message : "Erreur"),
      }
    );
  };

  const confirmDelete = () => {
    if (propertyToDelete !== null) {
      deleteMutation.mutate(propertyToDelete);
    }
  };

  const formatPrice = (price: number | string) => {
    return new Intl.NumberFormat("fr-HT", { style: "currency", currency: "HTG" }).format(Number(price));
  };

  return (
    <div className={styles.container}>
      <div className={styles.topBar}>
        <div className={styles.searchContainer}>
          <Search className={styles.searchIcon} size={18} />
          <Input
            className={styles.searchInput}
            placeholder="Rechercher par titre ou ville..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className={styles.filters}>
          <Select value={categoryFilter} onValueChange={(val) => setCategoryFilter(val as any)}>
            <SelectTrigger style={{ width: "200px" }}>
              <SelectValue placeholder="Catégorie" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="_empty">Toutes les catégories</SelectItem>
              {Object.entries(CATEGORY_LABELS).map(([val, label]) => (
                <SelectItem key={val} value={val}>{label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Propriété</th>
              <th>Agent</th>
              <th>Catégorie</th>
              <th>Prix</th>
              <th className={styles.centerCol}>En vedette</th>
              <th className={styles.rightCol}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  <td>
                    <div className={styles.propertyInfo}>
                      <Skeleton style={{ width: "3rem", height: "3rem", borderRadius: "0.25rem" }} />
                      <div>
                        <Skeleton style={{ width: "150px", height: "1rem", marginBottom: "0.25rem" }} />
                        <Skeleton style={{ width: "100px", height: "0.875rem" }} />
                      </div>
                    </div>
                  </td>
                  <td><Skeleton style={{ width: "120px", height: "1rem" }} /></td>
                  <td><Skeleton style={{ width: "100px", height: "1rem" }} /></td>
                  <td><Skeleton style={{ width: "90px", height: "1rem" }} /></td>
                  <td className={styles.centerCol}><Skeleton style={{ width: "24px", height: "24px", margin: "0 auto", borderRadius: "50%" }} /></td>
                  <td className={styles.rightCol}><Skeleton style={{ width: "32px", height: "32px", marginLeft: "auto" }} /></td>
                </tr>
              ))
            ) : data?.properties.length === 0 ? (
              <tr>
                <td colSpan={6} className={styles.emptyState}>
                  Aucune propriété trouvée.
                </td>
              </tr>
            ) : (
              data?.properties.map((prop) => (
                <tr key={prop.id}>
                  <td>
                    <div className={styles.propertyInfo}>
                      {prop.primaryImageUrl ? (
                        <img src={prop.primaryImageUrl} alt="" className={styles.thumb} />
                      ) : (
                        <div className={styles.thumbPlaceholder}><Building size={16} /></div>
                      )}
                      <div>
                        <div className={styles.propTitle}>{prop.title}</div>
                        <div className={styles.propCity}>{prop.city}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div className={styles.agentName}>{prop.agentName || "-"}</div>
                  </td>
                  <td>{CATEGORY_LABELS[prop.category] || prop.category}</td>
                  <td className={styles.price}>{formatPrice(prop.price)}</td>
                  <td className={styles.centerCol}>
                    <Button 
                      variant="ghost" 
                      size="icon-md" 
                      onClick={() => handleToggleFeatured(prop.id, !!prop.isFeatured)}
                      disabled={isUpdating}
                      aria-label="Basculer en vedette"
                    >
                      <Star className={prop.isFeatured ? styles.starFilled : styles.starOutline} size={20} />
                    </Button>
                  </td>
                  <td className={styles.rightCol}>
                    <Button 
                      variant="ghost" 
                      size="icon-md" 
                      className={styles.deleteBtn}
                      onClick={() => setPropertyToDelete(prop.id)}
                      aria-label="Supprimer la propriété"
                    >
                      <Trash size={18} />
                    </Button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {data && data.totalPages > 1 && (
        <div className={styles.paginationContainer}>
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious 
                  href="#" 
                  onClick={(e) => { e.preventDefault(); setPage((p) => Math.max(1, p - 1)); }} 
                  className={page === 1 ? styles.disabledPagination : ""}
                />
              </PaginationItem>
              <PaginationItem>
                <span className={styles.pageText}>Page {page} sur {data.totalPages}</span>
              </PaginationItem>
              <PaginationItem>
                <PaginationNext 
                  href="#" 
                  onClick={(e) => { e.preventDefault(); setPage((p) => Math.min(data.totalPages, p + 1)); }}
                  className={page >= data.totalPages ? styles.disabledPagination : ""}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}

      <Dialog open={propertyToDelete !== null} onOpenChange={(open) => { if (!open) setPropertyToDelete(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmer la suppression</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer cette propriété ? Les images associées seront également supprimées. Cette action est irréversible.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setPropertyToDelete(null)}>Annuler</Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteMutation.isPending}>
              Supprimer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};