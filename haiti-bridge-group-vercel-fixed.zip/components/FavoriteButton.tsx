import React from "react";
import { Heart } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "../helpers/useAuth";
import styles from "./FavoriteButton.module.css";

interface FavoriteButtonProps {
  propertyId: number;
  isFavorited: boolean;
  onToggle: () => void;
  size?: "sm" | "md";
  className?: string;
}

export const FavoriteButton: React.FC<FavoriteButtonProps> = ({
  propertyId,
  isFavorited,
  onToggle,
  size = "md",
  className = "",
}) => {
  const { authState } = useAuth();

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();

    if (authState.type !== "authenticated") {
      toast("Connectez-vous pour sauvegarder vos favoris");
      return;
    }

    onToggle();
  };

  return (
    <button
      type="button"
      className={`${styles.button} ${styles[size]} ${isFavorited ? styles.favorited : styles.unfavorited} ${className}`}
      onClick={handleClick}
      aria-label={isFavorited ? "Retirer des favoris" : "Ajouter aux favoris"}
    >
      <Heart
        className={styles.icon}
        size={size === "sm" ? 16 : 20}
      />
    </button>
  );
};