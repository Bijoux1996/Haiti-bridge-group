import React from "react";
import { Link } from "react-router-dom";
import { MapPin, Bed, Bath, Square, Home } from "lucide-react";
import { Badge } from "./Badge";
import { PropertyListOutputItem } from "../endpoints/property/list_GET.schema";
import { FavoriteButton } from "./FavoriteButton";
import { WhatsAppButton } from "./WhatsAppButton";
import styles from "./PropertyCard.module.css";

export const PropertyCard: React.FC<{ 
  property: PropertyListOutputItem; 
  className?: string;
  isFavorited?: boolean;
  onToggleFavorite?: () => void;
}> = ({ property, className, isFavorited = false, onToggleFavorite }) => {
  const priceFormatted = new Intl.NumberFormat('fr-HT', { 
    style: 'currency', 
    currency: 'USD', 
    maximumFractionDigits: 0 
  }).format(Number(property.price));
  
  const categoryLabels: Record<string, string> = {
    apartment: "Appartement",
    commercial: "Commercial",
    house_rent: "À Louer",
    house_sale: "À Vendre",
    land_sale: "Terrain"
  };

  return (
    <Link to={`/properties/${property.id}`} className={`${styles.card} ${className || ""}`}>
      <div className={styles.imageContainer}>
        {property.primaryImageUrl ? (
          <img src={property.primaryImageUrl} alt={property.title} className={styles.image} />
        ) : (
          <div className={styles.placeholderImage}><Home size={48} /></div>
        )}
        <div className={styles.badges}>
          {property.isFeatured && <Badge variant="secondary" className={styles.featuredBadge}>Populaire</Badge>}
          <Badge variant="primary" className={styles.categoryBadge}>{categoryLabels[property.category] || property.category}</Badge>
        </div>
        {onToggleFavorite && (
          <div 
            className={styles.favoriteButtonWrapper}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
          >
            <FavoriteButton
              propertyId={property.id}
              isFavorited={isFavorited}
              onToggle={onToggleFavorite}
              size="sm"
            />
          </div>
        )}
        {property.whatsapp && (
          <div 
            className={styles.whatsappButtonWrapper}
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
          >
            <WhatsAppButton
              phone={property.whatsapp}
              propertyId={property.id}
              agentId={0} // Fallback to 0 since list schema doesn't provide agentId
              propertyTitle={property.title}
              propertyPrice={property.price}
              propertyCity={property.city}
              variant="icon"
            />
          </div>
        )}
        <div className={styles.price}>{priceFormatted}</div>
      </div>
      <div className={styles.content}>
        <h3 className={styles.title}>{property.title}</h3>
        <p className={styles.location}>
          <MapPin size={14} /> 
          {property.city}{property.address ? `, ${property.address}` : ""}
        </p>
        <div className={styles.features}>
          {property.bedrooms != null && (
            <div className={styles.feature}>
              <Bed size={16} /> <span>{property.bedrooms}</span>
            </div>
          )}
          {property.bathrooms != null && (
            <div className={styles.feature}>
              <Bath size={16} /> <span>{property.bathrooms}</span>
            </div>
          )}
          {property.areaSqft != null && (
            <div className={styles.feature}>
              <Square size={16} /> <span>{property.areaSqft} m²</span>
            </div>
          )}
        </div>
        {property.agentName && (
          <div className={styles.agent}>
            Agent: <span>{property.agentName}</span>
          </div>
        )}
      </div>
    </Link>
  );
};