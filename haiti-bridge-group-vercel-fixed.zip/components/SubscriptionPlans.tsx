import React from "react";
import { Check, X as XIcon } from "lucide-react";
import { Selectable } from "kysely";
import { SubscriptionPlans as SubscriptionPlansModel } from "../helpers/schema";
import { Button } from "./Button";
import { Skeleton } from "./Skeleton";
import { useScrollReveal } from "../helpers/useScrollReveal";
import styles from "./SubscriptionPlans.module.css";

export interface SubscriptionPlansProps {
  plans: Selectable<SubscriptionPlansModel>[];
  currentPlanSlug?: string | null;
  onSelectPlan: (planId: number) => void;
  isLoading?: boolean;
  isSubscribingId?: number | null;
}

export const SubscriptionPlans: React.FC<SubscriptionPlansProps> = ({
  plans,
  currentPlanSlug,
  onSelectPlan,
  isLoading = false,
  isSubscribingId = null,
}) => {
  const reveal = useScrollReveal();

  if (isLoading) {
    return (
      <div className={styles.grid}>
        {[1, 2, 3].map((i) => (
          <div key={i} className={styles.card}>
            <Skeleton className={styles.skeletonTitle} />
            <Skeleton className={styles.skeletonPrice} />
            <Skeleton className={styles.skeletonDesc} />
            <div className={styles.skeletonFeatures}>
              {[1, 2, 3, 4, 5].map((j) => (
                <Skeleton key={j} className={styles.skeletonFeature} />
              ))}
            </div>
            <Skeleton className={styles.skeletonButton} />
          </div>
        ))}
      </div>
    );
  }

  // Ensure plans are sorted safely if not already, though the API does this
  const sortedPlans = [...plans].sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <div className={styles.grid}>
      {sortedPlans.map((plan, index) => {
        const isCurrent = plan.slug === currentPlanSlug;
        const isPro = plan.slug.includes("pro");
        const isVip = plan.slug.includes("vip");
        const price = Number(plan.priceHtg);
        const isFree = isNaN(price) || price === 0;

        const maxListingsText =
          plan.maxListings >= 999
            ? "Annonces illimitées"
            : `Jusqu'à ${plan.maxListings} annonces`;

        const maxPhotosText =
          plan.maxPhotosPerListing >= 50
            ? "Photos illimitées"
            : `Jusqu'à ${plan.maxPhotosPerListing} photos par annonce`;

        // Configure features for this plan
        const features = [
          { included: true, text: maxListingsText },
          { included: true, text: maxPhotosText },
          { included: plan.canFeatureListings, text: "Annonces en vedette" },
          { included: plan.hasProBadge, text: "Badge Pro" },
          { included: plan.hasVipBadge, text: "Badge VIP" },
          { included: plan.hasPrioritySupport, text: "Support prioritaire" },
        ];

        // Determine Button Props
        let btnVariant: "primary" | "secondary" | "outline" = "primary";
        if (isCurrent) btnVariant = "outline";
        else if (isVip) btnVariant = "secondary";

        const btnText = isCurrent
          ? "Plan Actuel"
          : isSubscribingId === plan.id
            ? "Traitement..."
            : "Choisir ce plan";

        return (
          <div
            key={plan.id}
            ref={reveal}
            className={`${styles.card} ${isPro ? styles.cardPro : ""} ${isVip ? styles.cardVip : ""}`}
            style={{ transitionDelay: `${index * 100}ms` }}
          >
            {isPro && <div className={styles.popularBadge}>Populaire</div>}

            <div className={styles.cardHeader}>
              <h3 className={styles.planName}>{plan.name}</h3>
              <div className={styles.planPrice}>
                {isFree ? (
                  "Gratuit"
                ) : (
                  <>
                    <span className={styles.currency}>
                      {new Intl.NumberFormat("fr-HT").format(price)} HTG
                    </span>
                    <span className={styles.period}>/mois</span>
                  </>
                )}
              </div>
              <p className={styles.planDesc}>{plan.description}</p>
            </div>

            <div className={styles.features}>
              {features.map((feature, idx) => (
                <div
                  key={idx}
                  className={`${styles.featureItem} ${feature.included ? "" : styles.featureExcluded}`}
                >
                  {feature.included ? (
                    <Check className={styles.checkIcon} size={20} />
                  ) : (
                    <XIcon className={styles.xIcon} size={20} />
                  )}
                  <span>{feature.text}</span>
                </div>
              ))}
            </div>

            <div className={styles.cardFooter}>
              <Button
                variant={btnVariant}
                disabled={isCurrent || isSubscribingId === plan.id}
                className={styles.actionButton}
                onClick={() => onSelectPlan(plan.id)}
              >
                {btnText}
              </Button>
            </div>
          </div>
        );
      })}
    </div>
  );
};