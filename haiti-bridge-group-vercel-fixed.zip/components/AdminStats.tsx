import React from "react";
import { useAdminStats } from "../helpers/useAdmin";
import { Users, UserCheck, Building, ShieldAlert, Clock, CheckCircle, AlertTriangle } from "lucide-react";
import { Skeleton } from "./Skeleton";
import styles from "./AdminStats.module.css";

export const AdminStats = () => {
  const { data, isLoading } = useAdminStats();

  const statCards = [
    { label: "Total Utilisateurs", value: data?.totalUsers, icon: Users, colorClass: styles.iconBlue },
    { label: "Agents", value: data?.totalAgents, icon: UserCheck, colorClass: styles.iconGreen },
    { label: "Propriétés", value: data?.totalProperties, icon: Building, colorClass: styles.iconGold },
    { label: "Vérifications en attente", value: data?.pendingVerifications, icon: ShieldAlert, colorClass: styles.iconOrange },
    { label: "Abonnements en attente", value: data?.pendingSubscriptions, icon: Clock, colorClass: styles.iconOrange },
    { label: "Signalements en attente", value: data?.pendingReports, icon: AlertTriangle, colorClass: styles.iconOrange },
    { label: "Abonnements actifs", value: data?.activeSubscriptions, icon: CheckCircle, colorClass: styles.iconGreen },
  ];

  if (isLoading) {
    return (
      <div className={styles.grid}>
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className={styles.card}>
            <Skeleton style={{ width: "3rem", height: "3rem", borderRadius: "50%" }} />
            <Skeleton style={{ width: "80%", height: "2.5rem", marginTop: "1rem" }} />
            <Skeleton style={{ width: "60%", height: "1rem", marginTop: "0.5rem" }} />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className={styles.grid}>
      {statCards.map((stat, i) => (
        <div key={i} className={styles.card}>
          <div className={styles.cardHeader}>
            <div className={`${styles.iconBox} ${stat.colorClass}`}>
              <stat.icon size={24} />
            </div>
          </div>
          <div className={styles.cardContent}>
            <div className={styles.cardValue}>{stat.value ?? 0}</div>
            <div className={styles.cardLabel}>{stat.label}</div>
          </div>
        </div>
      ))}
    </div>
  );
};