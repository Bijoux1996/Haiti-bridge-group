import React, { useState, useEffect } from "react";
import { useAdminReports, useAdminUpdateReport } from "../helpers/useReports";
import { ReportStatus, ReportStatusArrayValues } from "../helpers/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./Select";
import { Badge } from "./Badge";
import { Button } from "./Button";
import { Skeleton } from "./Skeleton";
import { Pagination, PaginationContent, PaginationItem, PaginationNext, PaginationPrevious } from "./Pagination";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "./DropdownMenu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "./Dialog";
import { Textarea } from "./Textarea";
import { toast } from "sonner";
import { MoreHorizontal, FileWarning } from "lucide-react";
import { Link } from "react-router-dom";
import styles from "./AdminReportsList.module.css";

const STATUS_LABELS: Record<string, string> = {
  pending: "En attente",
  reviewed: "Examiné",
  dismissed: "Rejeté",
  action_taken: "Action prise",
};

const REASON_LABELS: Record<string, string> = {
  fake_listing: "Annonce fausse",
  wrong_info: "Informations incorrectes",
  scam: "Arnaque",
  inappropriate: "Contenu inapproprié",
  other: "Autre",
};

export const AdminReportsList = () => {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState<ReportStatus | "_empty">("_empty");
  const [updateModal, setUpdateModal] = useState<{ reportId: number; status: ReportStatus; open: boolean } | null>(null);
  const [adminNotes, setAdminNotes] = useState("");

  useEffect(() => {
    setPage(1);
  }, [statusFilter]);

  const { data, isLoading } = useAdminReports({
    page,
    limit: 20,
    status: statusFilter === "_empty" ? undefined : statusFilter,
  });

  const { mutate: updateReport, isPending: isUpdating } = useAdminUpdateReport();

  const handleOpenUpdateModal = (reportId: number, status: ReportStatus) => {
    setUpdateModal({ reportId, status, open: true });
    setAdminNotes("");
  };

  const submitStatusUpdate = () => {
    if (!updateModal) return;
    updateReport(
      {
        reportId: updateModal.reportId,
        status: updateModal.status,
        adminNotes: adminNotes.trim() || undefined,
      },
      {
        onSuccess: () => {
          toast.success("Le statut du signalement a été mis à jour.");
          setUpdateModal(null);
        },
        onError: (err) => {
          toast.error(err instanceof Error ? err.message : "Erreur lors de la mise à jour");
        },
      }
    );
  };

  const formatDate = (dateStr: string | Date | null) => {
    if (!dateStr) return "-";
    return new Intl.DateTimeFormat("fr-HT", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(dateStr));
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "action_taken":
        return <Badge variant="success">{STATUS_LABELS[status]}</Badge>;
      case "pending":
        return <Badge variant="warning">{STATUS_LABELS[status]}</Badge>;
      case "reviewed":
        return <Badge variant="secondary" className={styles.badgeInfo}>{STATUS_LABELS[status]}</Badge>;
      case "dismissed":
        return <Badge variant="outline">{STATUS_LABELS[status]}</Badge>;
      default:
        return <span className={styles.emptyDash}>-</span>;
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.topBar}>
        <div className={styles.filters}>
          <Select value={statusFilter} onValueChange={(val) => setStatusFilter(val as any)}>
            <SelectTrigger style={{ width: "220px" }}>
              <SelectValue placeholder="Statut du signalement" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="_empty">Tous les statuts</SelectItem>
              {ReportStatusArrayValues.map((status) => (
                <SelectItem key={status} value={status}>
                  {STATUS_LABELS[status]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Annonce</th>
              <th>Signalé par</th>
              <th>Raison</th>
              <th>Description</th>
              <th>Statut</th>
              <th>Date</th>
              <th className={styles.rightCol}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  <td>
                    <Skeleton style={{ width: "150px", height: "1rem", marginBottom: "0.25rem" }} />
                    <Skeleton style={{ width: "100px", height: "0.875rem" }} />
                  </td>
                  <td>
                    <Skeleton style={{ width: "120px", height: "1rem" }} />
                  </td>
                  <td>
                    <Skeleton style={{ width: "100px", height: "1rem" }} />
                  </td>
                  <td>
                    <Skeleton style={{ width: "200px", height: "1rem" }} />
                  </td>
                  <td>
                    <Skeleton style={{ width: "80px", height: "1.5rem", borderRadius: "1rem" }} />
                  </td>
                  <td>
                    <Skeleton style={{ width: "100px", height: "1rem" }} />
                  </td>
                  <td className={styles.rightCol}>
                    <Skeleton style={{ width: "32px", height: "2rem", marginLeft: "auto" }} />
                  </td>
                </tr>
              ))
            ) : data?.reports.length === 0 ? (
              <tr>
                <td colSpan={7}>
                  <div className={styles.emptyState}>
                    <FileWarning size={48} className={styles.emptyIcon} />
                    <p>Aucun signalement trouvé.</p>
                  </div>
                </td>
              </tr>
            ) : (
              data?.reports.map((report) => (
                <tr key={report.id}>
                  <td>
                    <div className={styles.propertyInfo}>
                      <Link to={`/properties/${report.propertyId}`} className={styles.propertyTitle}>
                        {report.propertyTitle}
                      </Link>
                      <div className={styles.propertyCity}>{report.propertyCity}</div>
                    </div>
                  </td>
                  <td>
                    <div className={styles.reporterInfo}>
                      {report.reporterName && <span className={styles.reporterName}>{report.reporterName}</span>}
                      {report.reporterEmail && <span className={styles.reporterEmail}>{report.reporterEmail}</span>}
                      {!report.reporterName && !report.reporterEmail && <span className={styles.emptyDash}>Anonyme</span>}
                    </div>
                  </td>
                  <td>{REASON_LABELS[report.reason] || report.reason}</td>
                  <td className={styles.descriptionCell}>
                    <div className={styles.descriptionTruncate} title={report.description}>
                      {report.description}
                    </div>
                  </td>
                  <td>{getStatusBadge(report.status)}</td>
                  <td>{formatDate(report.createdAt)}</td>
                  <td className={styles.rightCol}>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon-md" aria-label="Actions">
                          <MoreHorizontal size={16} />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleOpenUpdateModal(report.id, "reviewed")}>
                          Marquer comme examiné
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleOpenUpdateModal(report.id, "action_taken")}>
                          Marquer comme action prise
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleOpenUpdateModal(report.id, "dismissed")} className={styles.destructiveAction}>
                          Rejeter le signalement
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {data && data.totalPages > 1 && (
        <div className={styles.paginationContainer}>
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    setPage((p) => Math.max(1, p - 1));
                  }}
                  className={page === 1 ? styles.disabledPagination : ""}
                />
              </PaginationItem>
              <PaginationItem>
                <span className={styles.pageText}>
                  Page {page} sur {data.totalPages}
                </span>
              </PaginationItem>
              <PaginationItem>
                <PaginationNext
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    setPage((p) => Math.min(data.totalPages, p + 1));
                  }}
                  className={page >= data.totalPages ? styles.disabledPagination : ""}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}

      {/* Update Modal */}
      {updateModal && (
        <Dialog open={updateModal.open} onOpenChange={(open) => !open && setUpdateModal(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Mettre à jour le statut</DialogTitle>
              <DialogDescription>
                Nouveau statut : <strong>{STATUS_LABELS[updateModal.status]}</strong>. Vous pouvez ajouter une note administrative (facultatif).
              </DialogDescription>
            </DialogHeader>
            <div className={styles.modalBody}>
              <Textarea
                placeholder="Notes de l'administrateur (facultatif)..."
                value={adminNotes}
                onChange={(e) => setAdminNotes(e.target.value)}
              />
            </div>
            <DialogFooter>
              <Button variant="secondary" onClick={() => setUpdateModal(null)} disabled={isUpdating}>
                Annuler
              </Button>
              <Button onClick={submitStatusUpdate} disabled={isUpdating}>
                Confirmer
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};