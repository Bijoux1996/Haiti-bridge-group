import React, { useState } from "react";
import {
  Form,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
  useForm,
} from "./Form";
import { Input } from "./Input";
import { Textarea } from "./Textarea";
import { Button } from "./Button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./Select";
import { Badge } from "./Badge";
import { Trash2, Plus, ImageIcon, Camera, X } from "lucide-react";
import { toast } from "sonner";
import { useCreateProperty } from "../helpers/useAgentProperties";
import { schema as createSchema } from "../endpoints/property/create_POST.schema";
import { z } from "zod";
import { compressImage } from "../helpers/compressImage";
import styles from "./DashboardAddProperty.module.css";

interface Props {
  onPropertyAdded: () => void;
}

export const DashboardAddProperty = ({ onPropertyAdded }: Props) => {
  const { mutate, isPending } = useCreateProperty();
  const [newImageUrl, setNewImageUrl] = useState("");
  const [isCompressing, setIsCompressing] = useState(false);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const form = useForm({
    schema: createSchema,
    defaultValues: {
      title: "",
      description: "",
      price: 0,
      category: "house_sale",
      city: "",
      address: "",
      phone: "",
      whatsapp: "",
      bedrooms: undefined,
      bathrooms: undefined,
      areaSqft: undefined,
      imageUrls: [],
    },
  });

  const showBedBath = !["land_sale", "commercial"].includes(
    form.values.category
  );

  const handleAddImage = () => {
    if (newImageUrl.trim()) {
      form.setValues((prev) => ({
        ...prev,
        imageUrls: [...(prev.imageUrls || []), newImageUrl.trim()],
      }));
      setNewImageUrl("");
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setIsCompressing(true);
    try {
      const compressedUrls = await Promise.all(
        files.map((file) => compressImage(file))
      );
      
      form.setValues((prev) => ({
        ...prev,
        imageUrls: [...(prev.imageUrls || []), ...compressedUrls].slice(0, 10),
      }));
    } catch (error) {
      toast.error("Erreur lors de la compression des images");
    } finally {
      setIsCompressing(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleMakePrimary = (index: number) => {
    form.setValues((prev) => {
      const updated = [...(prev.imageUrls || [])];
      const [item] = updated.splice(index, 1);
      updated.unshift(item);
      return { ...prev, imageUrls: updated };
    });
  };

  const handleRemoveImage = (index: number) => {
    form.setValues((prev) => {
      const updated = [...(prev.imageUrls || [])];
      updated.splice(index, 1);
      return { ...prev, imageUrls: updated };
    });
  };

  const onSubmit = (data: z.infer<typeof createSchema>) => {
    mutate(data, {
      onSuccess: () => {
        toast.success("Propriété ajoutée avec succès");
        onPropertyAdded();
      },
      onError: (err) => {
        toast.error(err.message || "Erreur lors de l'ajout");
      },
    });
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h2 className={styles.title}>Créer une Nouvelle Propriété</h2>
        <p className={styles.subtitle}>
          Remplissez le formulaire ci-dessous pour ajouter une annonce.
        </p>
      </div>

      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className={styles.formGrid}
        >
          {/* Main Details Section */}
          <div className={styles.section}>
            <h3 className={styles.sectionTitle}>Détails Principaux</h3>

            <FormItem name="title">
              <FormLabel>Titre de l'annonce</FormLabel>
              <FormControl>
                <Input
                  placeholder="Ex: Belle villa avec vue sur mer"
                  value={form.values.title}
                  onChange={(e) =>
                    form.setValues((prev) => ({
                      ...prev,
                      title: e.target.value,
                    }))
                  }
                />
              </FormControl>
              <FormMessage />
            </FormItem>

            <div className={styles.row2}>
              <FormItem name="category">
                <FormLabel>Catégorie</FormLabel>
                <FormControl>
                  <Select
                    value={form.values.category}
                    onValueChange={(val: any) =>
                      form.setValues((prev) => ({ ...prev, category: val }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Catégorie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="house_sale">Vente</SelectItem>
                      <SelectItem value="house_rent">Location</SelectItem>
                      <SelectItem value="land_sale">Terrain</SelectItem>
                      <SelectItem value="apartment">Appartement</SelectItem>
                      <SelectItem value="commercial">Commercial</SelectItem>
                    </SelectContent>
                  </Select>
                </FormControl>
                <FormMessage />
              </FormItem>

              <FormItem name="price">
                <FormLabel>Prix ($ USD)</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={form.values.price || ""}
                    onChange={(e) =>
                      form.setValues((prev) => ({
                        ...prev,
                        price: e.target.value ? Number(e.target.value) : 0,
                      }))
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            </div>

            <FormItem name="description">
              <FormLabel>Description complète</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Décrivez la propriété en détail..."
                  rows={5}
                  value={form.values.description}
                  onChange={(e) =>
                    form.setValues((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          </div>

          {/* Characteristics Section */}
          <div className={styles.section}>
            <h3 className={styles.sectionTitle}>Caractéristiques</h3>

            <div className={styles.row3}>
              {showBedBath && (
                <>
                  <FormItem name="bedrooms">
                    <FormLabel>Chambres</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        placeholder="Nb"
                        value={form.values.bedrooms || ""}
                        onChange={(e) =>
                          form.setValues((prev) => ({
                            ...prev,
                            bedrooms: e.target.value
                              ? Number(e.target.value)
                              : undefined,
                          }))
                        }
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>

                  <FormItem name="bathrooms">
                    <FormLabel>Salles de bain</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        placeholder="Nb"
                        value={form.values.bathrooms || ""}
                        onChange={(e) =>
                          form.setValues((prev) => ({
                            ...prev,
                            bathrooms: e.target.value
                              ? Number(e.target.value)
                              : undefined,
                          }))
                        }
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                </>
              )}

              <FormItem name="areaSqft">
                <FormLabel>Surface (m²)</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    min="0"
                    placeholder="Superficie"
                    value={form.values.areaSqft || ""}
                    onChange={(e) =>
                      form.setValues((prev) => ({
                        ...prev,
                        areaSqft: e.target.value
                          ? Number(e.target.value)
                          : undefined,
                      }))
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            </div>
          </div>

          {/* Location & Contact */}
          <div className={styles.section}>
            <h3 className={styles.sectionTitle}>Localisation et Contact</h3>

            <div className={styles.row2}>
              <FormItem name="city">
                <FormLabel>Ville (Requis)</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Ex: Pétion-Ville"
                    value={form.values.city}
                    onChange={(e) =>
                      form.setValues((prev) => ({
                        ...prev,
                        city: e.target.value,
                      }))
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>

              <FormItem name="address">
                <FormLabel>Adresse (Optionnel)</FormLabel>
                <FormControl>
                  <Input
                    placeholder="Ex: Rue Panaméricaine"
                    value={form.values.address}
                    onChange={(e) =>
                      form.setValues((prev) => ({
                        ...prev,
                        address: e.target.value,
                      }))
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            </div>

            <div className={styles.row2}>
              <FormItem name="phone">
                <FormLabel>Téléphone</FormLabel>
                <FormControl>
                  <Input
                    placeholder="+509 XXXX XXXX"
                    value={form.values.phone}
                    onChange={(e) =>
                      form.setValues((prev) => ({
                        ...prev,
                        phone: e.target.value,
                      }))
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>

              <FormItem name="whatsapp">
                <FormLabel>Numéro WhatsApp</FormLabel>
                <FormControl>
                  <Input
                    placeholder="+509 XXXX XXXX"
                    value={form.values.whatsapp}
                    onChange={(e) =>
                      form.setValues((prev) => ({
                        ...prev,
                        whatsapp: e.target.value,
                      }))
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            </div>
          </div>

          {/* Images Section */}
          <div className={styles.section}>
            <h3 className={styles.sectionTitle}>Galerie Photos</h3>
            <div className={styles.imageBlock}>
              <FormItem name="imageUrls">
                <FormLabel>Photos de la propriété</FormLabel>
                
                <input
                  type="file"
                  accept="image/jpeg, image/png, image/webp"
                  multiple
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  style={{ display: "none" }}
                />

                <div 
                  className={styles.dropzone} 
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Camera size={32} className={styles.dropzoneIcon} />
                  <p className={styles.dropzoneTitle}>Cliquez ou glissez vos photos ici</p>
                  <p className={styles.dropzoneSubtitle}>
                    Formats acceptés: JPEG, PNG, WebP - Max 10 photos<br/>
                    (Appuyez pour ouvrir la galerie)
                  </p>
                  {isCompressing && (
                    <p className={styles.compressingText}>Compression des images en cours...</p>
                  )}
                </div>

                <div className={styles.urlToggle}>
                  <button
                    type="button"
                    className={styles.urlToggleButton}
                    onClick={() => setShowUrlInput(!showUrlInput)}
                  >
                    {showUrlInput ? "Cacher l'ajout par URL" : "Ajouter par URL"}
                  </button>
                </div>

                {showUrlInput && (
                  <div className={styles.imageInputRow}>
                    <Input
                      placeholder="https://exemple.com/image.jpg"
                      value={newImageUrl}
                      onChange={(e) => setNewImageUrl(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          handleAddImage();
                        }
                      }}
                    />
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={handleAddImage}
                    >
                      Ajouter
                    </Button>
                  </div>
                )}

                {form.values.imageUrls && form.values.imageUrls.length > 0 ? (
                  <div className={styles.imageGrid}>
                    {form.values.imageUrls.map((url, i) => (
                      <div key={i} className={styles.imageGridItem}>
                        <img
                          src={url}
                          alt={`Preview ${i}`}
                          className={styles.gridImage}
                          onClick={() => handleMakePrimary(i)}
                          title="Cliquer pour définir comme principale"
                        />
                        {i === 0 && (
                          <div className={styles.primaryOverlay}>
                            Principale
                          </div>
                        )}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemoveImage(i);
                          }}
                          className={styles.gridRemoveBtn}
                          title="Supprimer"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className={styles.noImages}>
                    <ImageIcon size={32} />
                    <p>Aucune image ajoutée</p>
                  </div>
                )}
                <FormMessage />
              </FormItem>
            </div>
          </div>

          <div className={styles.submitActions}>
            <Button
              type="submit"
              size="lg"
              className={styles.submitBtn}
              disabled={isPending || isCompressing}
            >
              {isPending ? "Création en cours..." : "Publier l'annonce"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};