import React, { useState } from "react";
import { useMyListings } from "../helpers/useAgentProperties";
import { DashboardPropertyCard } from "./DashboardPropertyCard";
import { DashboardEditProperty } from "./DashboardEditProperty";
import { Skeleton } from "./Skeleton";
import { Button } from "./Button";
import { Plus, Building2 } from "lucide-react";
import styles from "./DashboardProperties.module.css";

interface Props {
  onAddClick: () => void;
}

export const DashboardProperties = ({ onAddClick }: Props) => {
  const { data, isPending } = useMyListings();
  const [editingId, setEditingId] = useState<number | null>(null);

  if (isPending) {
    return (
      <div className={styles.loadingGrid}>
        {[...Array(6)].map((_, i) => (
          <div key={i} className={styles.skeletonCard}>
            <Skeleton className={styles.skeletonImage} />
            <div className={styles.skeletonContent}>
              <Skeleton style={{ width: "80%", height: "1.5rem" }} />
              <Skeleton style={{ width: "40%", height: "1rem" }} />
              <Skeleton style={{ width: "60%", height: "1.5rem" }} />
              <Skeleton style={{ width: "100%", height: "2.5rem", marginTop: "auto" }} />
            </div>
          </div>
        ))}
      </div>
    );
  }

  const properties = data?.properties || [];

  if (properties.length === 0) {
    return (
      <div className={styles.emptyState}>
        <div className={styles.emptyIconWrapper}>
          <Building2 size={48} className={styles.emptyIcon} />
        </div>
        <h3 className={styles.emptyTitle}>Aucune propriété</h3>
        <p className={styles.emptyText}>
          Vous n'avez pas encore ajouté de propriétés. Commencez à construire
          votre portfolio dès aujourd'hui.
        </p>
        <Button onClick={onAddClick} size="lg" className={styles.emptyAction}>
          <Plus size={20} />
          Ajouter ma première propriété
        </Button>
      </div>
    );
  }

  return (
    <div className={styles.container}>
      <div className={styles.statsBar}>
        <div className={styles.statLabel}>
          Total: <strong>{properties.length}</strong> propriété
          {properties.length > 1 ? "s" : ""}
        </div>
      </div>
      <div className={styles.grid}>
        {properties.map((property) =>
          editingId === property.id ? (
            <div key={property.id} className={styles.editRow}>
              <DashboardEditProperty
                property={property}
                onCancel={() => setEditingId(null)}
                onSaved={() => setEditingId(null)}
              />
            </div>
          ) : (
            <DashboardPropertyCard
              key={property.id}
              property={property}
              onEdit={() => setEditingId(property.id)}
            />
          )
        )}
      </div>
    </div>
  );
};