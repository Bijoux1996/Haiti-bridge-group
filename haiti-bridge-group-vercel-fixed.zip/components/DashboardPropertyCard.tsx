import React, { useState } from "react";
import { Link } from "react-router-dom";
import { PropertyWithImages } from "../endpoints/property/my-listings_GET.schema";
import { useDeleteProperty } from "../helpers/useAgentProperties";
import { Badge } from "./Badge";
import { Button } from "./Button";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "./Dialog";
import {
  MapPin,
  BedDouble,
  Bath,
  Edit,
  Trash2,
  Calendar,
  Image as ImageIcon,
} from "lucide-react";
import { toast } from "sonner";
import styles from "./DashboardPropertyCard.module.css";

interface Props {
  property: PropertyWithImages;
  onEdit: () => void;
}

export const categoryTranslations: Record<string, string> = {
  house_sale: "Vente",
  house_rent: "Location",
  land_sale: "Terrain",
  apartment: "Appartement",
  commercial: "Commercial",
};

export const DashboardPropertyCard = ({ property, onEdit }: Props) => {
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const deleteMutation = useDeleteProperty();

  const primaryImage =
    property.images.find((img) => img.isPrimary)?.imageUrl ||
    property.images[0]?.imageUrl;

  const formattedPrice = new Intl.NumberFormat("fr-HT", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(Number(property.price));

  const formattedDate = new Intl.DateTimeFormat("fr-HT", {
    day: "numeric",
    month: "short",
    year: "numeric",
  }).format(new Date(property.createdAt as unknown as string));

  const handleDelete = () => {
    deleteMutation.mutate(
      { id: property.id },
      {
        onSuccess: () => {
          toast.success("Propriété supprimée avec succès");
          setIsDeleteDialogOpen(false);
        },
        onError: (err) => {
          toast.error(err.message || "Erreur lors de la suppression");
        },
      }
    );
  };

  return (
    <div className={styles.card}>
      <div className={styles.imageContainer}>
        {primaryImage ? (
          <img
            src={primaryImage}
            alt={property.title}
            className={styles.image}
          />
        ) : (
          <div className={styles.placeholderImage}>
            <ImageIcon size={48} />
          </div>
        )}
        <div className={styles.badges}>
          <Badge variant="primary">
            {categoryTranslations[property.category] || property.category}
          </Badge>
          {property.isFeatured && (
            <Badge variant="secondary" className={styles.featuredBadge}>
              En vedette
            </Badge>
          )}
        </div>
        <div className={styles.priceOverlay}>{formattedPrice}</div>
      </div>

      <div className={styles.content}>
        <div className={styles.header}>
          <h3 className={styles.title} title={property.title}>
            {property.title}
          </h3>
          <div className={styles.location}>
            <MapPin size={14} />
            <span>{property.city}</span>
          </div>
        </div>

        <div className={styles.metrics}>
          {property.bedrooms != null && property.bedrooms > 0 && (
            <div className={styles.metric}>
              <BedDouble size={16} />
              <span>{property.bedrooms} Ch.</span>
            </div>
          )}
          {property.bathrooms != null && property.bathrooms > 0 && (
            <div className={styles.metric}>
              <Bath size={16} />
              <span>{property.bathrooms} Sdb.</span>
            </div>
          )}
          <div className={styles.metric}>
            <Calendar size={16} />
            <span>{formattedDate}</span>
          </div>
        </div>

        <div className={styles.actions}>
          <Button asChild variant="outline" className={styles.viewBtn}>
            <Link to={`/properties/${property.id}`}>Voir</Link>
          </Button>

          <div className={styles.agentActions}>
            <Button
              variant="secondary"
              size="icon-md"
              onClick={onEdit}
              title="Modifier"
              aria-label="Modifier"
            >
              <Edit size={16} />
            </Button>

            <Dialog
              open={isDeleteDialogOpen}
              onOpenChange={setIsDeleteDialogOpen}
            >
              <DialogTrigger asChild>
                <Button
                  variant="destructive"
                  size="icon-md"
                  title="Supprimer"
                  aria-label="Supprimer"
                >
                  <Trash2 size={16} />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Supprimer la propriété</DialogTitle>
                  <DialogDescription>
                    Êtes-vous sûr de vouloir supprimer "{property.title}" ?
                    Cette action est irréversible et supprimera également toutes
                    les photos associées.
                  </DialogDescription>
                </DialogHeader>
                <DialogFooter>
                  <DialogClose asChild>
                    <Button variant="outline">Annuler</Button>
                  </DialogClose>
                  <Button
                    variant="destructive"
                    onClick={handleDelete}
                    disabled={deleteMutation.isPending}
                  >
                    {deleteMutation.isPending ? "Suppression..." : "Supprimer"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
    </div>
  );
};