import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
  useForm,
} from "./Form";
import { Input } from "./Input";
import { Textarea } from "./Textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./Select";
import { Button } from "./Button";
import { Spinner } from "./Spinner";
import { FileDropzone } from "./FileDropzone";
import { useAuth } from "../helpers/useAuth";
import {
  schema,
  postRegisterAgent,
} from "../endpoints/auth/register-agent_POST.schema";
import { Image as ImageIcon } from "lucide-react";
import styles from "./AgentRegisterForm.module.css";

export type AgentRegisterFormData = z.infer<typeof schema>;

interface AgentRegisterFormProps {
  className?: string;
  defaultValues?: Partial<AgentRegisterFormData>;
}

export const AgentRegisterForm: React.FC<AgentRegisterFormProps> = ({
  className,
  defaultValues,
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const { onLogin } = useAuth();
  const navigate = useNavigate();

  const form = useForm({
    schema,
    defaultValues: defaultValues || {
      email: "",
      password: "",
      displayName: "",
      phone: "",
      whatsapp: "",
      bio: "",
      documentType: "id_card",
      documentData: "",
    },
  });

  const handleSubmit = async (data: AgentRegisterFormData) => {
    setError(null);
    setIsLoading(true);

    try {
      const result = await postRegisterAgent(data);
      onLogin(result.user);
      navigate("/dashboard");
    } catch (err) {
      console.error("Agent registration error:", err);
      if (err instanceof Error) {
        setError(err.message || "L'inscription a échoué. Veuillez réessayer.");
      } else {
        setError("L'inscription a échoué. Veuillez réessayer.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileSelected = (files: File[]) => {
    const file = files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      form.setValues((prev: any) => ({
        ...prev,
        documentData: base64String,
      }));
      setPreviewUrl(base64String);
    };
    reader.readAsDataURL(file);
  };

  return (
    <Form {...form}>
      {error && <div className={styles.errorMessage}>{error}</div>}
      <form
        onSubmit={form.handleSubmit((data) =>
          handleSubmit(data as AgentRegisterFormData)
        )}
        className={`${styles.form} ${className || ""}`}
      >
        <FormItem name="displayName">
          <FormLabel>Nom complet</FormLabel>
          <FormControl>
            <Input
              placeholder="Votre nom complet"
              value={form.values.displayName || ""}
              onChange={(e) =>
                form.setValues((prev: any) => ({
                  ...prev,
                  displayName: e.target.value,
                }))
              }
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <FormItem name="email">
          <FormLabel>Adresse email</FormLabel>
          <FormControl>
            <Input
              type="email"
              placeholder="votre@email.com"
              value={form.values.email || ""}
              onChange={(e) =>
                form.setValues((prev: any) => ({
                  ...prev,
                  email: e.target.value,
                }))
              }
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <FormItem name="password">
          <FormLabel>Mot de passe</FormLabel>
          <FormControl>
            <Input
              type="password"
              placeholder="••••••••"
              value={form.values.password || ""}
              onChange={(e) =>
                form.setValues((prev: any) => ({
                  ...prev,
                  password: e.target.value,
                }))
              }
            />
          </FormControl>
          <FormDescription>
            Au moins 8 caractères avec majuscule, minuscule et chiffre
          </FormDescription>
          <FormMessage />
        </FormItem>

        <div className={styles.row}>
          <FormItem name="phone">
            <FormLabel>Numéro de téléphone</FormLabel>
            <FormControl>
              <Input
                placeholder="+509 XXXX-XXXX"
                value={form.values.phone || ""}
                onChange={(e) =>
                  form.setValues((prev: any) => ({
                    ...prev,
                    phone: e.target.value,
                  }))
                }
              />
            </FormControl>
            <FormMessage />
          </FormItem>

          <FormItem name="whatsapp">
            <FormLabel>WhatsApp</FormLabel>
            <FormControl>
              <Input
                placeholder="+509 XXXX-XXXX"
                value={form.values.whatsapp || ""}
                onChange={(e) =>
                  form.setValues((prev: any) => ({
                    ...prev,
                    whatsapp: e.target.value,
                  }))
                }
              />
            </FormControl>
            <FormDescription>Laissez vide si identique au téléphone</FormDescription>
            <FormMessage />
          </FormItem>
        </div>

        <FormItem name="bio">
          <FormLabel>Bio / Présentation</FormLabel>
          <FormControl>
            <Textarea
              placeholder="Décrivez votre expérience et spécialités"
              value={form.values.bio || ""}
              onChange={(e) =>
                form.setValues((prev: any) => ({
                  ...prev,
                  bio: e.target.value,
                }))
              }
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <div className={styles.documentSection}>
          <h3 className={styles.sectionTitle}>Vérification d'identité</h3>
          <p className={styles.sectionDescription}>
            Pour devenir agent vérifié, nous avons besoin d'une pièce d'identité valide.
          </p>

          <FormItem name="documentType">
            <FormLabel>Type de document d'identité</FormLabel>
            <FormControl>
              <Select
                value={form.values.documentType}
                onValueChange={(value) =>
                  form.setValues((prev: any) => ({
                    ...prev,
                    documentType: value as "id_card" | "passport",
                  }))
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionnez un type de document" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="id_card">Carte d'identité nationale</SelectItem>
                  <SelectItem value="passport">Passeport</SelectItem>
                </SelectContent>
              </Select>
            </FormControl>
            <FormMessage />
          </FormItem>

          <FormItem name="documentData">
            <FormLabel>Document d'identité</FormLabel>
            <FormControl>
              <div>
                {!previewUrl ? (
                  <FileDropzone
                    accept="image/jpeg,image/png"
                    maxSize={5 * 1024 * 1024}
                    onFilesSelected={handleFileSelected}
                    icon={<ImageIcon size={32} />}
                    title="Cliquez ou glissez une image ici"
                    subtitle="JPG, PNG jusqu'à 5MB"
                  />
                ) : (
                  <div className={styles.previewContainer}>
                    <img src={previewUrl} alt="Document preview" className={styles.previewImage} />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setPreviewUrl(null);
                        form.setValues((prev: any) => ({ ...prev, documentData: "" }));
                      }}
                      className={styles.changeFileButton}
                    >
                      Changer d'image
                    </Button>
                  </div>
                )}
              </div>
            </FormControl>
            <FormMessage />
          </FormItem>
        </div>

        <Button
          type="submit"
          disabled={isLoading}
          className={styles.submitButton}
        >
          {isLoading ? (
            <>
              <Spinner size="sm" /> Création du compte...
            </>
          ) : (
            "Créer mon compte Agent"
          )}
        </Button>
      </form>
    </Form>
  );
};