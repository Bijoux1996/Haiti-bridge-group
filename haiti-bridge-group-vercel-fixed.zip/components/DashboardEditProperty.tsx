import React, { useState } from "react";
import {
  Form,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
  useForm,
} from "./Form";
import { Input } from "./Input";
import { Textarea } from "./Textarea";
import { Button } from "./Button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./Select";
import { Badge } from "./Badge";
import { Trash2, ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { useUpdateProperty } from "../helpers/useAgentProperties";
import { schema as updateSchema } from "../endpoints/property/update_POST.schema";
import { PropertyWithImages } from "../endpoints/property/my-listings_GET.schema";
import { z } from "zod";
import styles from "./DashboardEditProperty.module.css";

interface Props {
  property: PropertyWithImages;
  onCancel: () => void;
  onSaved: () => void;
}

export const DashboardEditProperty = ({
  property,
  onCancel,
  onSaved,
}: Props) => {
  const { mutate, isPending } = useUpdateProperty();
  const [newImageUrl, setNewImageUrl] = useState("");

  const form = useForm({
    schema: updateSchema,
    defaultValues: {
      id: property.id,
      title: property.title,
      description: property.description || "",
      price: Number(property.price),
      category: property.category,
      city: property.city,
      address: property.address || "",
      phone: property.phone || "",
      whatsapp: property.whatsapp || "",
      bedrooms: property.bedrooms || undefined,
      bathrooms: property.bathrooms || undefined,
      areaSqft: property.areaSqft || undefined,
      imageUrls: property.images.map((img) => img.imageUrl),
    },
  });

  const showBedBath = !["land_sale", "commercial"].includes(
    form.values.category || "house_sale"
  );

  const handleAddImage = () => {
    if (newImageUrl.trim()) {
      form.setValues((prev) => ({
        ...prev,
        imageUrls: [...(prev.imageUrls || []), newImageUrl.trim()],
      }));
      setNewImageUrl("");
    }
  };

  const handleRemoveImage = (index: number) => {
    form.setValues((prev) => {
      const updated = [...(prev.imageUrls || [])];
      updated.splice(index, 1);
      return { ...prev, imageUrls: updated };
    });
  };

  const onSubmit = (data: z.infer<typeof updateSchema>) => {
    mutate(data, {
      onSuccess: () => {
        toast.success("Propriété modifiée avec succès");
        onSaved();
      },
      onError: (err) => {
        toast.error(err.message || "Erreur lors de la modification");
      },
    });
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h3 className={styles.title}>Modifier: {property.title}</h3>
      </div>

      <Form {...form}>
        <form
          onSubmit={form.handleSubmit(onSubmit)}
          className={styles.formGrid}
        >
          <div className={styles.row2}>
            <FormItem name="title">
              <FormLabel>Titre</FormLabel>
              <FormControl>
                <Input
                  value={form.values.title}
                  onChange={(e) =>
                    form.setValues((prev) => ({
                      ...prev,
                      title: e.target.value,
                    }))
                  }
                />
              </FormControl>
              <FormMessage />
            </FormItem>

            <FormItem name="category">
              <FormLabel>Catégorie</FormLabel>
              <FormControl>
                <Select
                  value={form.values.category}
                  onValueChange={(val: any) =>
                    form.setValues((prev) => ({ ...prev, category: val }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Catégorie" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="house_sale">Vente</SelectItem>
                    <SelectItem value="house_rent">Location</SelectItem>
                    <SelectItem value="land_sale">Terrain</SelectItem>
                    <SelectItem value="apartment">Appartement</SelectItem>
                    <SelectItem value="commercial">Commercial</SelectItem>
                  </SelectContent>
                </Select>
              </FormControl>
              <FormMessage />
            </FormItem>
          </div>

          <div className={styles.row3}>
            <FormItem name="price">
              <FormLabel>Prix ($ USD)</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  min="0"
                  value={form.values.price || ""}
                  onChange={(e) =>
                    form.setValues((prev) => ({
                      ...prev,
                      price: e.target.value ? Number(e.target.value) : 0,
                    }))
                  }
                />
              </FormControl>
              <FormMessage />
            </FormItem>

            <FormItem name="city">
              <FormLabel>Ville</FormLabel>
              <FormControl>
                <Input
                  value={form.values.city}
                  onChange={(e) =>
                    form.setValues((prev) => ({
                      ...prev,
                      city: e.target.value,
                    }))
                  }
                />
              </FormControl>
              <FormMessage />
            </FormItem>
            
            <FormItem name="areaSqft">
              <FormLabel>Surface (m²)</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  min="0"
                  value={form.values.areaSqft || ""}
                  onChange={(e) =>
                    form.setValues((prev) => ({
                      ...prev,
                      areaSqft: e.target.value
                        ? Number(e.target.value)
                        : undefined,
                    }))
                  }
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          </div>

          <FormItem name="description">
            <FormLabel>Description</FormLabel>
            <FormControl>
              <Textarea
                rows={3}
                value={form.values.description}
                onChange={(e) =>
                  form.setValues((prev) => ({
                    ...prev,
                    description: e.target.value,
                  }))
                }
              />
            </FormControl>
            <FormMessage />
          </FormItem>

          {showBedBath && (
            <div className={styles.row2}>
              <FormItem name="bedrooms">
                <FormLabel>Chambres</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    min="0"
                    value={form.values.bedrooms || ""}
                    onChange={(e) =>
                      form.setValues((prev) => ({
                        ...prev,
                        bedrooms: e.target.value
                          ? Number(e.target.value)
                          : undefined,
                      }))
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>

              <FormItem name="bathrooms">
                <FormLabel>Salles de bain</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    min="0"
                    value={form.values.bathrooms || ""}
                    onChange={(e) =>
                      form.setValues((prev) => ({
                        ...prev,
                        bathrooms: e.target.value
                          ? Number(e.target.value)
                          : undefined,
                      }))
                    }
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            </div>
          )}

          <div className={styles.imageBlock}>
            <FormItem name="imageUrls">
              <FormLabel>Images (URLs)</FormLabel>
              <div className={styles.imageInputRow}>
                <Input
                  placeholder="https://..."
                  value={newImageUrl}
                  onChange={(e) => setNewImageUrl(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleAddImage();
                    }
                  }}
                />
                <Button
                  type="button"
                  variant="secondary"
                  onClick={handleAddImage}
                >
                  Ajouter
                </Button>
              </div>

              {form.values.imageUrls && form.values.imageUrls.length > 0 ? (
                <div className={styles.imagePreviewList}>
                  {form.values.imageUrls.map((url, i) => (
                    <div key={i} className={styles.imagePreviewItem}>
                      <img
                        src={url}
                        alt={`Preview ${i}`}
                        className={styles.imageThumbnail}
                      />
                      <div className={styles.imageUrlText}>{url}</div>
                      {i === 0 && (
                        <Badge
                          variant="secondary"
                          className={styles.primaryBadge}
                        >
                          Principale
                        </Badge>
                      )}
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-sm"
                        onClick={() => handleRemoveImage(i)}
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className={styles.noImages}>
                  <ImageIcon size={24} />
                  <p>Aucune image</p>
                </div>
              )}
              <FormMessage />
            </FormItem>
          </div>

          <div className={styles.actions}>
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
};