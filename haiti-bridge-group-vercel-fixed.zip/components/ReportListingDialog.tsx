import React, { useState } from "react";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
  DialogFooter,
} from "./Dialog";
import { Button } from "./Button";
import { Flag } from "lucide-react";
import { useAuth } from "../helpers/useAuth";
import { useCreateReport } from "../helpers/useReports";
import {
  Form,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
  useForm,
} from "./Form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./Select";
import { Textarea } from "./Textarea";
import { Input } from "./Input";
import { toast } from "sonner";
import { ReportReasonArrayValues } from "../helpers/schema";
import styles from "./ReportListingDialog.module.css";

const REASON_LABELS: Record<string, string> = {
  fake_listing: "Annonce fausse",
  wrong_info: "Informations incorrectes",
  scam: "Arnaque",
  inappropriate: "Contenu inapproprié",
  other: "Autre",
};

const authSchema = z.object({
  reason: z.enum(ReportReasonArrayValues, {
    required_error: "Veuillez sélectionner une raison",
  }),
  description: z
    .string()
    .min(10, "La description doit contenir au moins 10 caractères.")
    .max(2000, "La description est trop longue."),
});

const unauthSchema = z.object({
  reason: z.enum(ReportReasonArrayValues, {
    required_error: "Veuillez sélectionner une raison",
  }),
  description: z
    .string()
    .min(10, "La description doit contenir au moins 10 caractères.")
    .max(2000, "La description est trop longue."),
  reporterEmail: z.string().email("Adresse email invalide."),
});

interface Props {
  propertyId: number;
  propertyTitle: string;
  trigger?: React.ReactNode;
}

export const ReportListingDialog: React.FC<Props> = ({
  propertyId,
  propertyTitle,
  trigger,
}) => {
  const [open, setOpen] = useState(false);
  const { authState } = useAuth();
  const isAuthenticated = authState.type === "authenticated";

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" className={styles.triggerButton}>
            <Flag size={16} />
            Signaler cette annonce
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className={styles.dialogContent}>
        <DialogHeader>
          <DialogTitle>Signaler cette annonce</DialogTitle>
          <DialogDescription>
            Si vous pensez que cette annonce ({propertyTitle}) est frauduleuse ou inappropriée, veuillez nous le signaler.
          </DialogDescription>
        </DialogHeader>

        {isAuthenticated ? (
          <AuthenticatedForm propertyId={propertyId} onSuccess={() => setOpen(false)} onCancel={() => setOpen(false)} />
        ) : (
          <UnauthenticatedForm propertyId={propertyId} onSuccess={() => setOpen(false)} onCancel={() => setOpen(false)} />
        )}
      </DialogContent>
    </Dialog>
  );
};

const AuthenticatedForm = ({ propertyId, onSuccess, onCancel }: { propertyId: number; onSuccess: () => void; onCancel: () => void }) => {
  const form = useForm({
    schema: authSchema,
    defaultValues: { description: "" },
  });
  const { mutate: createReport, isPending } = useCreateReport();

  const onSubmit = (values: z.infer<typeof authSchema>) => {
    createReport(
      { propertyId, ...values },
      {
        onSuccess: () => {
          toast.success("Signalement envoyé avec succès. Nous examinerons votre demande.");
          form.setValues((prev) => ({ ...prev, description: "" }));
          onSuccess();
        },
        onError: (err) => {
          toast.error(err instanceof Error ? err.message : "Erreur lors de l'envoi du signalement.");
        },
      }
    );
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className={styles.formContainer}>
        <FormItem name="reason">
          <FormLabel>Raison du signalement (requis)</FormLabel>
          <FormControl>
            <Select
              value={form.values.reason}
              onValueChange={(val) => form.setValues((prev) => ({ ...prev, reason: val as any }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionnez une raison" />
              </SelectTrigger>
              <SelectContent>
                {ReportReasonArrayValues.map((reason) => (
                  <SelectItem key={reason} value={reason}>
                    {REASON_LABELS[reason]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </FormControl>
          <FormMessage />
        </FormItem>

        <FormItem name="description">
          <FormLabel>Description (requis)</FormLabel>
          <FormControl>
            <Textarea
              placeholder="Décrivez pourquoi vous signalez cette annonce (minimum 10 caractères)..."
              value={form.values.description}
              onChange={(e) => form.setValues((prev) => ({ ...prev, description: e.target.value }))}
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <DialogFooter>
          <Button variant="secondary" onClick={onCancel} type="button" disabled={isPending}>
            Annuler
          </Button>
          <Button type="submit" disabled={isPending}>
            Envoyer le signalement
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
};

const UnauthenticatedForm = ({ propertyId, onSuccess, onCancel }: { propertyId: number; onSuccess: () => void; onCancel: () => void }) => {
  const form = useForm({
    schema: unauthSchema,
    defaultValues: { description: "", reporterEmail: "" },
  });
  const { mutate: createReport, isPending } = useCreateReport();

  const onSubmit = (values: z.infer<typeof unauthSchema>) => {
    createReport(
      { propertyId, ...values },
      {
        onSuccess: () => {
          toast.success("Signalement envoyé avec succès. Nous examinerons votre demande.");
          form.setValues((prev) => ({ ...prev, description: "", reporterEmail: "" }));
          onSuccess();
        },
        onError: (err) => {
          toast.error(err instanceof Error ? err.message : "Erreur lors de l'envoi du signalement.");
        },
      }
    );
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className={styles.formContainer}>
        <FormItem name="reason">
          <FormLabel>Raison du signalement (requis)</FormLabel>
          <FormControl>
            <Select
              value={form.values.reason}
              onValueChange={(val) => form.setValues((prev) => ({ ...prev, reason: val as any }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionnez une raison" />
              </SelectTrigger>
              <SelectContent>
                {ReportReasonArrayValues.map((reason) => (
                  <SelectItem key={reason} value={reason}>
                    {REASON_LABELS[reason]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </FormControl>
          <FormMessage />
        </FormItem>

        <FormItem name="reporterEmail">
          <FormLabel>Votre email (requis)</FormLabel>
          <FormControl>
            <Input
              type="email"
              placeholder="email@exemple.com"
              value={form.values.reporterEmail}
              onChange={(e) => form.setValues((prev) => ({ ...prev, reporterEmail: e.target.value }))}
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <FormItem name="description">
          <FormLabel>Description (requis)</FormLabel>
          <FormControl>
            <Textarea
              placeholder="Décrivez pourquoi vous signalez cette annonce (minimum 10 caractères)..."
              value={form.values.description}
              onChange={(e) => form.setValues((prev) => ({ ...prev, description: e.target.value }))}
            />
          </FormControl>
          <FormMessage />
        </FormItem>

        <DialogFooter>
          <Button variant="secondary" onClick={onCancel} type="button" disabled={isPending}>
            Annuler
          </Button>
          <Button type="submit" disabled={isPending}>
            Envoyer le signalement
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
};