import React, { useState, useEffect } from "react";
import { useAdminSubscriptions, useAdminUpdateSubscription } from "../helpers/useAdmin";
import { useSubscriptionPlans } from "../helpers/useSubscription";
import { SubscriptionStatus } from "../helpers/schema";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./Select";
import { Badge } from "./Badge";
import { Button } from "./Button";
import { Skeleton } from "./Skeleton";
import { Pagination, PaginationContent, PaginationItem, PaginationNext, PaginationPrevious } from "./Pagination";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from "./DropdownMenu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "./Dialog";
import { MoreHorizontal } from "lucide-react";
import { toast } from "sonner";
import styles from "./AdminSubscriptionsList.module.css";

export const AdminSubscriptionsList = () => {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState<SubscriptionStatus | "_empty">("_empty");
  const [changePlanSubId, setChangePlanSubId] = useState<number | null>(null);
  const [selectedPlanId, setSelectedPlanId] = useState<string>("");

  useEffect(() => {
    setPage(1);
  }, [statusFilter]);

  const { data, isLoading } = useAdminSubscriptions({
    page,
    limit: 20,
    status: statusFilter === "_empty" ? undefined : statusFilter,
  });

  const { data: plansData } = useSubscriptionPlans();
  const { mutate: updateSubscription, isPending: isUpdating } = useAdminUpdateSubscription();

  const handleSubAction = (
    subscriptionId: number,
    action: "approve" | "reject" | "activate" | "deactivate" | "change_plan",
    newPlanId?: number
  ) => {
    updateSubscription(
      { subscriptionId, action, newPlanId },
      {
        onSuccess: () => {
          if (action === "approve") toast.success("Abonnement approuvé");
          if (action === "reject") toast.success("Abonnement rejeté");
          if (action === "activate") toast.success("Abonnement réactivé");
          if (action === "deactivate") toast.success("Abonnement désactivé");
          if (action === "change_plan") toast.success("Plan modifié avec succès");
          setChangePlanSubId(null);
        },
        onError: (err) => toast.error(err instanceof Error ? err.message : "Erreur de mise à jour"),
      }
    );
  };

  const handleChangePlan = () => {
    if (changePlanSubId && selectedPlanId) {
      handleSubAction(changePlanSubId, "change_plan", parseInt(selectedPlanId, 10));
    }
  };

  const formatDate = (dateStr: string | Date | null) => {
    if (!dateStr) return "-";
    return new Intl.DateTimeFormat("fr-HT", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(dateStr));
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active": return <Badge variant="success">Actif</Badge>;
      case "pending": return <Badge variant="warning">En attente</Badge>;
      case "expired": return <Badge variant="outline">Expiré</Badge>;
      case "cancelled": return <Badge variant="destructive">Annulé</Badge>;
      default: return <span className={styles.emptyDash}>-</span>;
    }
  };

  const formatPaymentMethod = (method: string | null) => {
    if (method === "moncash") return "MonCash";
    if (method === "natcash") return "NatCash";
    return "-";
  };

  return (
    <div className={styles.container}>
      <div className={styles.topBar}>
        <div className={styles.filters}>
          <Select value={statusFilter} onValueChange={(val) => setStatusFilter(val as any)}>
            <SelectTrigger style={{ width: "200px" }}>
              <SelectValue placeholder="Statut de l'abonnement" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="_empty">Tous les statuts</SelectItem>
              <SelectItem value="active">Actif</SelectItem>
              <SelectItem value="pending">En attente</SelectItem>
              <SelectItem value="expired">Expiré</SelectItem>
              <SelectItem value="cancelled">Annulé</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className={styles.tableWrapper}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Utilisateur</th>
              <th>Plan</th>
              <th>Statut</th>
              <th>Méthode</th>
              <th>Référence</th>
              <th>Date de création</th>
              <th className={styles.rightCol}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <tr key={i}>
                  <td>
                    <div>
                      <Skeleton style={{ width: "120px", height: "1rem", marginBottom: "0.25rem" }} />
                      <Skeleton style={{ width: "150px", height: "0.875rem" }} />
                    </div>
                  </td>
                  <td><Skeleton style={{ width: "80px", height: "1.5rem", borderRadius: "1rem" }} /></td>
                  <td><Skeleton style={{ width: "80px", height: "1.5rem", borderRadius: "1rem" }} /></td>
                  <td><Skeleton style={{ width: "70px", height: "1rem" }} /></td>
                  <td><Skeleton style={{ width: "90px", height: "1rem" }} /></td>
                  <td><Skeleton style={{ width: "120px", height: "1rem" }} /></td>
                  <td className={styles.rightCol}><Skeleton style={{ width: "140px", height: "2rem", marginLeft: "auto" }} /></td>
                </tr>
              ))
            ) : data?.subscriptions.length === 0 ? (
              <tr>
                <td colSpan={7} className={styles.emptyState}>
                  Aucun abonnement trouvé.
                </td>
              </tr>
            ) : (
              data?.subscriptions.map((sub) => (
                <tr key={sub.id}>
                  <td>
                    <div>
                      <div className={styles.userName}>{sub.userName}</div>
                      <div className={styles.userEmail}>{sub.userEmail}</div>
                    </div>
                  </td>
                  <td><Badge variant="primary">{sub.planName}</Badge></td>
                  <td>{getStatusBadge(sub.status)}</td>
                  <td>{formatPaymentMethod(sub.paymentMethod)}</td>
                  <td className={styles.reference}>{sub.paymentReference || "-"}</td>
                  <td>{formatDate(sub.createdAt)}</td>
                  <td className={styles.rightCol}>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon-sm">
                          <MoreHorizontal size={16} />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {sub.status === "pending" && (
                          <>
                            <DropdownMenuItem onClick={() => handleSubAction(sub.id, "approve")}>Approuver</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleSubAction(sub.id, "reject")} className={styles.destructiveText}>Rejeter</DropdownMenuItem>
                          </>
                        )}
                        {sub.status === "active" && (
                          <DropdownMenuItem onClick={() => handleSubAction(sub.id, "deactivate")} className={styles.destructiveText}>Désactiver</DropdownMenuItem>
                        )}
                        {(sub.status === "cancelled" || sub.status === "expired") && (
                          <DropdownMenuItem onClick={() => handleSubAction(sub.id, "activate")} className={styles.successText}>Réactiver</DropdownMenuItem>
                        )}
                        {(sub.status === "pending" || sub.status === "active" || sub.status === "cancelled" || sub.status === "expired") && (
                          <DropdownMenuSeparator />
                        )}
                        <DropdownMenuItem onClick={() => { setChangePlanSubId(sub.id); setSelectedPlanId(String(sub.planId)); }}>
                          Changer Plan
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {data && data.totalPages > 1 && (
        <div className={styles.paginationContainer}>
          <Pagination>
            <PaginationContent>
              <PaginationItem>
                <PaginationPrevious 
                  href="#" 
                  onClick={(e) => { e.preventDefault(); setPage((p) => Math.max(1, p - 1)); }} 
                  className={page === 1 ? styles.disabledPagination : ""}
                />
              </PaginationItem>
              <PaginationItem>
                <span className={styles.pageText}>Page {page} sur {data.totalPages}</span>
              </PaginationItem>
              <PaginationItem>
                <PaginationNext 
                  href="#" 
                  onClick={(e) => { e.preventDefault(); setPage((p) => Math.min(data.totalPages, p + 1)); }}
                  className={page >= data.totalPages ? styles.disabledPagination : ""}
                />
              </PaginationItem>
            </PaginationContent>
          </Pagination>
        </div>
      )}

      <Dialog open={changePlanSubId !== null} onOpenChange={(open) => { if (!open) setChangePlanSubId(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Changer le plan d'abonnement</DialogTitle>
          </DialogHeader>
          <div className={styles.dialogBody}>
            <Select value={selectedPlanId} onValueChange={setSelectedPlanId}>
              <SelectTrigger>
                <SelectValue placeholder="Sélectionnez un plan" />
              </SelectTrigger>
              <SelectContent>
                {plansData?.map(plan => (
                  <SelectItem key={plan.id} value={String(plan.id)}>{plan.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setChangePlanSubId(null)}>Annuler</Button>
            <Button onClick={handleChangePlan} disabled={isUpdating || !selectedPlanId}>Confirmer le changement</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};