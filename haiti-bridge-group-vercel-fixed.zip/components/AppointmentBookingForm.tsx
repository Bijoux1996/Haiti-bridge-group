import React, { useState } from "react";
import { toast } from "sonner";
import { CalendarIcon, CheckCircle2 } from "lucide-react";
import { schema as bookAppointmentSchema } from "../endpoints/appointment/book_POST.schema";
import { useBookAppointment } from "../helpers/useAppointments";
import {
  Form,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
  useForm,
} from "./Form";
import { Input } from "./Input";
import { Textarea } from "./Textarea";
import { Button } from "./Button";
import { Spinner } from "./Spinner";
import { Popover, PopoverContent, PopoverTrigger } from "./Popover";
import { Calendar } from "./Calendar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./Select";
import styles from "./AppointmentBookingForm.module.css";

interface AppointmentBookingFormProps {
  propertyId: number;
  agentName: string;
  className?: string;
}

const TIME_SLOTS = [
  "08:00",
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
];

export const AppointmentBookingForm: React.FC<AppointmentBookingFormProps> = ({
  propertyId,
  agentName,
  className,
}) => {
  const [isSuccess, setIsSuccess] = useState(false);
  const { mutateAsync: bookAppointment, isPending } = useBookAppointment();

  const form = useForm({
    defaultValues: {
      propertyId,
      clientName: "",
      clientPhone: "",
      clientEmail: "",
      preferredDate: "",
      preferredTime: "",
      message: "",
    },
    schema: bookAppointmentSchema,
  });

  const handleSubmit = async (values: typeof form.values) => {
    try {
      await bookAppointment(values);
      setIsSuccess(true);
      toast.success("Demande envoyée avec succès");
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Une erreur s'est produite lors de la réservation."
      );
    }
  };

  const handleReset = () => {
    form.setValues({
      propertyId,
      clientName: "",
      clientPhone: "",
      clientEmail: "",
      preferredDate: "",
      preferredTime: "",
      message: "",
    });
    setIsSuccess(false);
  };

  const selectedDateStr = form.values.preferredDate;
  const selectedDate = selectedDateStr
    ? new Date(
        parseInt(selectedDateStr.split("-")[0]),
        parseInt(selectedDateStr.split("-")[1]) - 1,
        parseInt(selectedDateStr.split("-")[2])
      )
    : undefined;

  if (isSuccess) {
    return (
      <div className={`${styles.container} ${className || ""}`}>
        <div className={styles.successState}>
          <CheckCircle2 className={styles.successIcon} />
          <h3 className={styles.successTitle}>Réservation réussie</h3>
          <p className={styles.successMessage}>
            ✅ Rendez-vous demandé avec succès ! {agentName} vous contactera
            pour confirmer.
          </p>
          <Button variant="outline" onClick={handleReset} className={styles.resetBtn}>
            Nouvelle demande
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className={`${styles.container} ${className || ""}`}>
      <h2 className={styles.heading}>📅 Prendre Rendez-vous</h2>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)} className={styles.form}>
          <FormItem name="clientName">
            <FormLabel>Nom complet*</FormLabel>
            <FormControl>
              <Input
                placeholder="Jean Dupont"
                value={form.values.clientName}
                onChange={(e) =>
                  form.setValues((prev) => ({
                    ...prev,
                    clientName: e.target.value,
                  }))
                }
              />
            </FormControl>
            <FormMessage />
          </FormItem>

          <FormItem name="clientPhone">
            <FormLabel>Téléphone*</FormLabel>
            <FormControl>
              <Input
                type="tel"
                placeholder="+509 XXXX XXXX"
                value={form.values.clientPhone}
                onChange={(e) =>
                  form.setValues((prev) => ({
                    ...prev,
                    clientPhone: e.target.value,
                  }))
                }
              />
            </FormControl>
            <FormMessage />
          </FormItem>

          <FormItem name="clientEmail">
            <FormLabel>Email</FormLabel>
            <FormControl>
              <Input
                type="email"
                placeholder="jean.dupont@example.com"
                value={form.values.clientEmail}
                onChange={(e) =>
                  form.setValues((prev) => ({
                    ...prev,
                    clientEmail: e.target.value,
                  }))
                }
              />
            </FormControl>
            <FormMessage />
          </FormItem>

          <div className={styles.row}>
            <FormItem name="preferredDate" className={styles.flexItem}>
              <FormLabel>Date souhaitée*</FormLabel>
              <FormControl>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      type="button"
                      className={`${styles.datePickerButton} ${
                        !selectedDate ? styles.mutedText : ""
                      }`}
                    >
                      <CalendarIcon className={styles.calendarIcon} />
                      {selectedDate
                        ? new Intl.DateTimeFormat("fr-FR", {
                            dateStyle: "medium",
                          }).format(selectedDate)
                        : "Choisir une date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent removeBackgroundAndPadding>
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={(date) => {
                        if (!date) return;
                        const y = date.getFullYear();
                        const m = String(date.getMonth() + 1).padStart(2, "0");
                        const d = String(date.getDate()).padStart(2, "0");
                        form.setValues((prev) => ({
                          ...prev,
                          preferredDate: `${y}-${m}-${d}`,
                        }));
                        form.validateField("preferredDate", { shallow: true });
                      }}
                      disabled={(date) => {
                        const today = new Date();
                        today.setHours(0, 0, 0, 0);
                        return date < today;
                      }}
                    />
                  </PopoverContent>
                </Popover>
              </FormControl>
              <FormMessage />
            </FormItem>

            <FormItem name="preferredTime" className={styles.flexItem}>
              <FormLabel>Heure souhaitée*</FormLabel>
              <FormControl>
                <Select
                  value={form.values.preferredTime}
                  onValueChange={(val) => {
                    form.setValues((prev) => ({
                      ...prev,
                      preferredTime: val,
                    }));
                    form.validateField("preferredTime", { shallow: true });
                  }}
                >
                  <SelectTrigger
                    onBlur={() =>
                      form.validateField("preferredTime", { shallow: true })
                    }
                  >
                    <SelectValue placeholder="Choisir une heure" />
                  </SelectTrigger>
                  <SelectContent>
                    {TIME_SLOTS.map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </FormControl>
              <FormMessage />
            </FormItem>
          </div>

          <FormItem name="message">
            <FormLabel>Message</FormLabel>
            <FormControl>
              <Textarea
                placeholder="Dites-nous en plus sur votre visite..."
                value={form.values.message || ""}
                onChange={(e) =>
                  form.setValues((prev) => ({
                    ...prev,
                    message: e.target.value,
                  }))
                }
              />
            </FormControl>
            <FormMessage />
          </FormItem>

          <Button
            type="submit"
            className={styles.submitBtn}
            disabled={isPending}
            size="lg"
          >
            {isPending ? (
              <>
                <Spinner size="sm" className={styles.spinner} />
                Réservation en cours...
              </>
            ) : (
              "Réserver un rendez-vous"
            )}
          </Button>
        </form>
      </Form>
    </div>
  );
};