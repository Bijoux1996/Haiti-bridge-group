import React from "react";
import { MessageCircle } from "lucide-react";
import {
  useLogWhatsAppContact,
  getWhatsAppUrl,
  generatePropertyMessage,
} from "../helpers/useWhatsApp";
import { Button } from "./Button";
import styles from "./WhatsAppButton.module.css";

export interface WhatsAppButtonProps {
  phone: string;
  propertyId: number;
  agentId: number;
  propertyTitle: string;
  propertyPrice: string | number;
  propertyCity: string;
  variant?: "full" | "compact" | "icon";
  className?: string;
}

export const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({
  phone,
  propertyId,
  agentId,
  propertyTitle,
  propertyPrice,
  propertyCity,
  variant = "full",
  className = "",
}) => {
  const { mutate } = useLogWhatsAppContact();

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    // Stop propagation and prevent default so it works safely inside Links/Cards
    e.preventDefault();
    e.stopPropagation();

    // Log the contact attempt
    mutate({ propertyId, agentId });

    // Generate message and URL
    const message = generatePropertyMessage({
      title: propertyTitle,
      price: propertyPrice,
      city: propertyCity,
      id: propertyId,
    });

    const url = getWhatsAppUrl(phone, message);

    // Open WhatsApp in a new tab/window
    window.open(url, "_blank", "noopener,noreferrer");
  };

  // Map our variants to the base Button sizes
  const buttonSize =
    variant === "compact" ? "sm" : variant === "icon" ? "icon-md" : "md";

  return (
    <Button
      onClick={handleClick}
      size={buttonSize}
      className={`${styles.whatsappButton} ${className}`}
      aria-label="Contacter sur WhatsApp"
    >
      <MessageCircle size={variant === "compact" ? 16 : 18} />
      {variant !== "icon" && <span>WhatsApp</span>}
    </Button>
  );
};