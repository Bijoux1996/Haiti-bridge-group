import { schema, OutputType } from "./agent_GET.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";

export async function handle(request: Request) {
  try {
    const url = new URL(request.url);
    const jsonString = url.searchParams.get("json");
    if (!jsonString) {
      throw new Error("Missing required json query parameter");
    }

    const input = schema.parse(superjson.parse(jsonString));
    const offset = (input.page - 1) * input.limit;

    const [reviews, statsResult] = await Promise.all([
      db
        .selectFrom("reviews")
        .innerJoin("users", "reviews.reviewerId", "users.id")
        .leftJoin("properties", "reviews.propertyId", "properties.id")
        .select([
          "reviews.id",
          "users.displayName as reviewerName",
          "users.avatarUrl as reviewerAvatar",
          "properties.title as propertyTitle",
          "reviews.rating",
          "reviews.comment",
          "reviews.createdAt",
        ])
        .where("reviews.agentId", "=", input.agentId)
        .orderBy("reviews.createdAt", "desc")
        .limit(input.limit)
        .offset(offset)
        .execute(),

      db
        .selectFrom("reviews")
        .select([
          "rating",
          db.fn.count<string | number>("id").as("count")
        ])
        .where("agentId", "=", input.agentId)
        .groupBy("rating")
        .execute()
    ]);

    let totalReviews = 0;
    let totalScore = 0;
    const distribution: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };

    for (const stat of statsResult) {
      const count = Number(stat.count);
      const rating = stat.rating;
      distribution[rating] = count;
      totalReviews += count;
      totalScore += rating * count;
    }

    const averageRating = totalReviews > 0 ? Math.round((totalScore / totalReviews) * 10) / 10 : 0;
    const totalPages = Math.ceil(totalReviews / input.limit);

    const output: OutputType = {
      reviews,
      stats: {
        averageRating,
        totalReviews,
        distribution: distribution as OutputType["stats"]["distribution"],
      },
      page: input.page,
      totalPages,
      totalCount: totalReviews,
    };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}