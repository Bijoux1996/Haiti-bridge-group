import { schema, OutputType } from "./create_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    if (user.id === input.agentId) {
      return new Response(
        superjson.stringify({ error: "Vous ne pouvez pas vous évaluer vous-même" }),
        { status: 400 }
      );
    }

    const agent = await db
      .selectFrom("users")
      .select("id")
      .where("id", "=", input.agentId)
      .where("role", "=", "agent")
      .executeTakeFirst();

    if (!agent) {
      return new Response(
        superjson.stringify({ error: "L'agent n'existe pas ou n'a pas le bon rôle" }),
        { status: 404 }
      );
    }

    let existingQuery = db
      .selectFrom("reviews")
      .select("id")
      .where("reviewerId", "=", user.id)
      .where("agentId", "=", input.agentId);

    if (input.propertyId) {
      existingQuery = existingQuery.where("propertyId", "=", input.propertyId);
    } else {
      existingQuery = existingQuery.where("propertyId", "is", null);
    }

    const existing = await existingQuery.executeTakeFirst();

    if (existing) {
      return new Response(
        superjson.stringify({ error: "Vous avez déjà laissé un avis pour cet agent sur cette propriété" }),
        { status: 409 }
      );
    }

    const result = await db
      .insertInto("reviews")
      .values({
        reviewerId: user.id,
        agentId: input.agentId,
        propertyId: input.propertyId || null,
        rating: input.rating,
        comment: input.comment || null,
      })
      .returning("id")
      .executeTakeFirstOrThrow();

    return new Response(
      superjson.stringify({ success: true, reviewId: result.id } satisfies OutputType),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: error instanceof Error && error.name === "NotAuthenticatedError" ? 401 : 400 }
    );
  }
}