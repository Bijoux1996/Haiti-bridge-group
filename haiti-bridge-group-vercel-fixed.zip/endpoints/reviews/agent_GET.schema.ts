import { z } from "zod";
import superjson from "superjson";

export const schema = z.object({
  agentId: z.number(),
  page: z.number().default(1),
  limit: z.number().default(10),
});

export type InputType = z.infer<typeof schema>;

export type ReviewItem = {
  id: number;
  reviewerName: string;
  reviewerAvatar: string | null;
  propertyTitle: string | null;
  rating: number;
  comment: string | null;
  createdAt: Date | null;
};

export type OutputType = {
  reviews: ReviewItem[];
  stats: {
    averageRating: number;
    totalReviews: number;
    distribution: {
      1: number;
      2: number;
      3: number;
      4: number;
      5: number;
    };
  };
  page: number;
  totalPages: number;
  totalCount: number;
};

export const getAgentReviews = async (
  input: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const url = new URL(
    `/_api/reviews/agent`,
    typeof window !== "undefined" ? window.location.origin : "http://localhost"
  );
  url.searchParams.set("json", superjson.stringify(input));

  const result = await fetch(url.toString(), {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to fetch reviews");
  }
  return superjson.parse<OutputType>(await result.text());
};