import { schema, OutputType } from "./check_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    let query = db
      .selectFrom("reviews")
      .select("id")
      .where("reviewerId", "=", user.id)
      .where("agentId", "=", input.agentId);

    if (input.propertyId) {
      query = query.where("propertyId", "=", input.propertyId);
    }

    const review = await query.executeTakeFirst();

    return new Response(
      superjson.stringify({ hasReviewed: !!review } satisfies OutputType),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: error instanceof Error && error.name === "NotAuthenticatedError" ? 401 : 400 }
    );
  }
}