import { schema, OutputType } from "./update_POST.schema";
import superjson from "superjson";
import { db } from "../../../helpers/db";
import { getServerUserSession } from "../../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    const bodyText = await request.text();
    const input = schema.parse(superjson.parse(bodyText));

    const updatedUser = await db
      .updateTable("users")
      .set({ avatarUrl: input.avatarUrl, updatedAt: new Date() })
      .where("id", "=", user.id)
      .returning(["avatarUrl"])
      .executeTakeFirstOrThrow();

    if (!updatedUser.avatarUrl) {
      throw new Error("Failed to update avatar.");
    }

    return new Response(
      superjson.stringify({ avatarUrl: updatedUser.avatarUrl } satisfies OutputType),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}