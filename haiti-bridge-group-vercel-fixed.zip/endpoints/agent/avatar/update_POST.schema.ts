import { z } from "zod";
import superjson from "superjson";

export const schema = z.object({
  // Max ~500KB of binary data translates to ~680KB in Base64 encoding. 
  // We use 700000 bytes as a safe limit.
  avatarUrl: z.string().startsWith("data:image/").max(700000, "Image size must be less than 500KB"),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  avatarUrl: string;
};

export const postUpdateAvatar = async (
  input: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const result = await fetch(`/_api/agent/avatar/update`, {
    method: "POST",
    body: superjson.stringify(input),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to update avatar");
  }
  return superjson.parse<OutputType>(await result.text());
};