import { schema, OutputType } from "./profile_GET.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";

export async function handle(request: Request) {
  try {
    const url = new URL(request.url);
    const slugParam = url.searchParams.get("slug");
    const { slug } = schema.parse({ slug: slugParam });

    // Look up the agent by slug
    const agent = await db
      .selectFrom("users")
      .where("slug", "=", slug)
            .where("role", "in", ["agent", "admin"])
      .selectAll()
      .executeTakeFirst();

    if (!agent) {
      return new Response(
        superjson.stringify({ error: "Agent non trouvé" }),
        { status: 404 }
      );
    }

    // Fetch agent's properties
    const properties = await db
      .selectFrom("properties")
      .leftJoin("propertyImages", (join) =>
        join
          .onRef("propertyImages.propertyId", "=", "properties.id")
          .on("propertyImages.isPrimary", "=", true)
      )
      .where("properties.agentId", "=", agent.id)
      .select([
        "properties.id",
        "properties.title",
        "properties.city",
        "properties.price",
        "properties.category",
        "properties.bedrooms",
        "properties.bathrooms",
        "properties.areaSqft",
        "properties.createdAt",
        "propertyImages.imageUrl",
      ])
      .orderBy("properties.createdAt", "desc")
      .limit(50)
      .execute();

    // Fetch review statistics
    const reviewsStats = await db
      .selectFrom("reviews")
      .where("agentId", "=", agent.id)
      .select((eb) => [
        eb.fn.count("id").as("totalReviews"),
        eb.fn.avg("rating").as("averageRating"),
      ])
      .executeTakeFirst();

    const output: OutputType = {
      agent: {
        id: agent.id,
        displayName: agent.displayName,
        email: agent.email,
        phone: agent.phone,
        whatsapp: agent.whatsapp,
        bio: agent.bio,
        avatarUrl: agent.avatarUrl,
        slug: agent.slug,
        verificationStatus: agent.verificationStatus,
        createdAt: agent.createdAt,
      },
      properties: properties.map((p) => ({
        id: p.id,
        title: p.title,
        city: p.city,
        price: p.price,
        category: p.category,
        bedrooms: p.bedrooms,
        bathrooms: p.bathrooms,
        areaSqft: p.areaSqft,
        imageUrl: p.imageUrl ?? null,
        createdAt: p.createdAt,
      })),
      stats: {
        totalProperties: properties.length,
        totalReviews: Number(reviewsStats?.totalReviews || 0),
        averageRating: reviewsStats?.averageRating ? Number(reviewsStats.averageRating) : null,
      },
    };

    return new Response(superjson.stringify(output satisfies OutputType));
  } catch (error: unknown) {
    console.error("Error fetching agent profile:", error);
    const msg = error instanceof Error ? error.message : "Erreur interne";
    return new Response(
      superjson.stringify({ error: msg }),
      { status: 400 }
    );
  }
}