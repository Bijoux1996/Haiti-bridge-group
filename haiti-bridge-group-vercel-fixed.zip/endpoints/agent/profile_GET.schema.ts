import { z } from "zod";
import superjson from "superjson";

export const schema = z.object({
  slug: z.string().min(1, "Slug is required")
});

export type OutputType = {
  agent: {
    id: number;
    displayName: string;
    email: string;
    phone: string | null;
    whatsapp: string | null;
    bio: string | null;
    avatarUrl: string | null;
    slug: string | null;
    verificationStatus: string | null;
    createdAt: Date | string | null;
  };
  properties: Array<{
    id: number;
    title: string;
    city: string;
    price: string | number;
    category: string;
    bedrooms: number | null;
    bathrooms: number | null;
    areaSqft: number | null;
    imageUrl: string | null;
    createdAt: Date | string | null;
  }>;
  stats: {
    totalProperties: number;
    averageRating: number | null;
    totalReviews: number;
  };
};

export const getAgentProfile = async (
  input: z.infer<typeof schema>,
  init?: RequestInit
): Promise<OutputType> => {
  const validated = schema.parse(input);
  const params = new URLSearchParams({ slug: validated.slug });
  const result = await fetch(`/_api/agent/profile?${params.toString()}`, {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error);
  }

  return superjson.parse<OutputType>(await result.text());
};