import { schema, OutputType } from "./log_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    let userId: number | null = null;
    try {
      const { user } = await getServerUserSession(request);
      userId = user.id;
    } catch (e) {
      // Ignore authentication errors as this is a public endpoint
    }

    await db
      .insertInto("whatsappContacts")
      .values({
        propertyId: input.propertyId,
        agentId: input.agentId,
        userId: userId,
        visitorIdentifier: null,
      })
      .execute();

    return new Response(
      superjson.stringify({ success: true } satisfies OutputType),
      {
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(
      superjson.stringify({
        error: error instanceof Error ? error.message : "Internal server error",
      }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}