import { z } from "zod";
import superjson from "superjson";

export const schema = z.object({
  period: z.enum(["week", "month", "all"]).optional().default("month"),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  totalContacts: number;
  contactsByProperty: Array<{
    propertyId: number;
    propertyTitle: string;
    contactCount: number;
  }>;
  recentContacts: Array<{
    id: number;
    propertyTitle: string;
    createdAt: Date | null;
  }>;
};

export const getAgentStats = async (
  input: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const url = new URL(
    `/_api/whatsapp/agent-stats`,
    typeof window !== "undefined" ? window.location.origin : "http://localhost"
  );
  url.searchParams.set("json", superjson.stringify(input));

  const result = await fetch(url.toString(), {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};