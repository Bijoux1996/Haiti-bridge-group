import { schema, OutputType } from "./agent-stats_GET.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    const url = new URL(request.url);
    const jsonString = url.searchParams.get("json");
    const json = jsonString ? superjson.parse(jsonString) : {};
    const input = schema.parse(json);

    let startDate: Date | undefined;
    const now = new Date();
    if (input.period === "week") {
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else if (input.period === "month") {
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    }

    // Base query for whatsappContacts belonging to the current agent
    let baseQuery = db
      .selectFrom("whatsappContacts")
      .where("agentId", "=", user.id);

    if (startDate) {
      baseQuery = baseQuery.where("createdAt", ">=", startDate);
    }

    // 1. Total Contacts
    const totalResult = await baseQuery
      .select(({ fn }) => fn.count<string>("id").as("count"))
      .executeTakeFirst();
    const totalContacts = totalResult ? Number(totalResult.count) : 0;

    // 2. Contacts by Property
    const contactsByPropertyRows = await baseQuery
      .innerJoin("properties", "properties.id", "whatsappContacts.propertyId")
      .select(({ fn }) => [
        "whatsappContacts.propertyId",
        "properties.title as propertyTitle",
        fn.count<string>("whatsappContacts.id").as("contactCount"),
      ])
      .groupBy(["whatsappContacts.propertyId", "properties.title"])
      .orderBy("contactCount", "desc")
      .limit(10)
      .execute();

    const contactsByProperty = contactsByPropertyRows.map((row) => ({
      propertyId: row.propertyId,
      propertyTitle: row.propertyTitle,
      contactCount: Number(row.contactCount),
    }));

    // 3. Recent Contacts
    const recentContactsRows = await baseQuery
      .innerJoin("properties", "properties.id", "whatsappContacts.propertyId")
      .select([
        "whatsappContacts.id",
        "properties.title as propertyTitle",
        "whatsappContacts.createdAt",
      ])
      .orderBy("whatsappContacts.createdAt", "desc")
      .limit(10)
      .execute();

    const recentContacts = recentContactsRows.map((row) => ({
      id: row.id,
      propertyTitle: row.propertyTitle,
      createdAt: row.createdAt ? new Date(row.createdAt) : null,
    }));

    const output: OutputType = {
      totalContacts,
      contactsByProperty,
      recentContacts,
    };

    return new Response(superjson.stringify(output), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({
        error: error instanceof Error ? error.message : "Internal server error",
      }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}