import { schema, OutputType } from "./reset-password_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { generatePasswordHash } from "../../helpers/generatePasswordHash";

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const { token, newPassword } = schema.parse(json);

    // Look for active token
    const resetToken = await db
      .selectFrom("passwordResetTokens")
      .selectAll()
      .where("token", "=", token)
      .where("usedAt", "is", null)
      .where("expiresAt", ">", new Date())
      .executeTakeFirst();

    if (!resetToken) {
      return new Response(
        superjson.stringify({ error: "Lien invalide ou expiré" }),
        { status: 400 }
      );
    }

    const passwordHash = await generatePasswordHash(newPassword);

    await db.transaction().execute(async (trx) => {
      // Upsert password logic because users signed up with external providers might lack a password entry
      const existingPwEntry = await trx
        .selectFrom("userPasswords")
        .select("id")
        .where("userId", "=", resetToken.userId)
        .executeTakeFirst();

      if (existingPwEntry) {
        await trx
          .updateTable("userPasswords")
          .set({ passwordHash })
          .where("userId", "=", resetToken.userId)
          .execute();
      } else {
        await trx
          .insertInto("userPasswords")
          .values({
            userId: resetToken.userId,
            passwordHash,
          })
          .execute();
      }

      // Invalidate current token and all other pending reset tokens for this user
      await trx
        .updateTable("passwordResetTokens")
        .set({ usedAt: new Date() })
        .where("userId", "=", resetToken.userId)
        .where("usedAt", "is", null)
        .execute();

      // Clear existing sessions to force re-login for security reasons
      await trx
        .deleteFrom("sessions")
        .where("userId", "=", resetToken.userId)
        .execute();
    });

    return new Response(
      superjson.stringify({ success: true } satisfies OutputType)
    );
  } catch (error: unknown) {
    console.error("Reset password error:", error);
    const msg = error instanceof Error ? error.message : "Erreur interne lors de la réinitialisation";
    return new Response(
      superjson.stringify({ error: msg }),
      { status: 400 }
    );
  }
}