import { z } from "zod";
import superjson from "superjson";

export const schema = z.object({
  phone: z.string().min(1, "Le numéro de téléphone est requis"),
  code: z.string().length(6, "Le code doit comporter exactement 6 chiffres"),
});

export type OutputType = {
  success: boolean;
  token: string;
};

export const postVerifySmsCode = async (
  body: z.infer<typeof schema>,
  init?: RequestInit
): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/auth/verify-sms-code`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error);
  }

  return superjson.parse<OutputType>(await result.text());
};