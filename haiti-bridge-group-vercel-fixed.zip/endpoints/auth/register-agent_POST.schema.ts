import { z } from "zod";
import { User } from "../../helpers/User";
import superjson from "superjson";

export const schema = z.object({
  email: z.string().email("Adresse email invalide"),
  password: z.string().min(8, "Le mot de passe doit contenir au moins 8 caractères"),
  displayName: z.string().min(1, "Le nom est requis"),
  phone: z.string().min(1, "Le numéro de téléphone est requis"),
  whatsapp: z.string().optional(),
  bio: z.string().optional(),
  documentType: z.enum(["id_card", "passport"], {
    errorMap: () => ({ message: "Type de document invalide" }),
  }),
  documentData: z.string().min(1, "Le document d'identité est requis"),
});

export type OutputType = {
  user: User;
};

export const postRegisterAgent = async (
  body: z.infer<typeof schema>,
  init?: RequestInit
): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/auth/register-agent`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
    credentials: "include", // Important for cookies to be sent and received
  });

  if (!result.ok) {
    const errorData = superjson.parse<{ message: string }>(await result.text());
    throw new Error(errorData.message || "L'inscription a échoué");
  }

  return superjson.parse<OutputType>(await result.text());
};