import { schema, OutputType } from "./verify-sms-code_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { randomBytes } from "crypto";

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const { phone, code } = schema.parse(json);

    // Validate the active SMS code
    const smsCode = await db
      .selectFrom("smsResetCodes")
      .selectAll()
      .where("phone", "=", phone)
      .where("code", "=", code)
      .where("usedAt", "is", null)
      .where("expiresAt", ">", new Date())
      .executeTakeFirst();

    if (!smsCode) {
      return new Response(
        superjson.stringify({ error: "Code invalide ou expiré" }),
        { status: 400 }
      );
    }

    const token = randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // Standard 1 hour token validity

    // Safely update the code usage and generate the new password reset token using a transaction
    await db.transaction().execute(async (trx) => {
      // 1. Mark SMS code as used
      await trx
        .updateTable("smsResetCodes")
        .set({ usedAt: new Date() })
        .where("id", "=", smsCode.id)
        .execute();

      // 2. Insert into the standard password reset tokens table
      await trx
        .insertInto("passwordResetTokens")
        .values({
          token,
          userId: smsCode.userId,
          expiresAt,
        })
        .execute();
    });

    return new Response(
      superjson.stringify({ success: true, token } satisfies OutputType)
    );
  } catch (error: unknown) {
    console.error("Verify SMS code error:", error);
    const msg = error instanceof Error ? error.message : "Erreur interne";
    return new Response(
      superjson.stringify({ error: msg }),
      { status: 400 }
    );
  }
}