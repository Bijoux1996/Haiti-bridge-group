import { db } from "../../helpers/db";
import { schema } from "./register-agent_POST.schema";
import { randomBytes } from "crypto";
import {
  setServerSession,
  SessionExpirationSeconds,
} from "../../helpers/getSetServerSession";
import { generatePasswordHash } from "../../helpers/generatePasswordHash";
import { generateUserSlug } from "../../helpers/generateUserSlug";
import superjson from "superjson";
import {
  sendEmail,
  getWelcomeAgentEmail,
  getAdminNewAgentEmail,
  ADMIN_EMAIL,
} from "../../helpers/sendEmail";

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const {
      email,
      password,
      displayName,
      phone,
      whatsapp,
      bio,
      documentType,
      documentData,
    } = schema.parse(json);

    // Check if email already exists
    const existingUser = await db
      .selectFrom("users")
      .select("id")
      .where("email", "=", email)
      .limit(1)
      .execute();

    if (existingUser.length > 0) {
      return new Response(
        superjson.stringify({ message: "Adresse email déjà utilisée" }),
        {
          status: 409,
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
    }

    const passwordHash = await generatePasswordHash(password);

    // Create new user and related records in transaction
    const newUser = await db.transaction().execute(async (trx) => {
      // Insert the user
      const [user] = await trx
        .insertInto("users")
        .values({
          email,
          displayName,
          role: "agent",
          verificationStatus: "pending",
          phone,
          whatsapp: whatsapp || null,
          bio: bio || null,
        })
        .returning(["id", "email", "displayName", "createdAt", "avatarUrl", "role"])
        .execute();

      // Store the password hash
      await trx
        .insertInto("userPasswords")
        .values({
          userId: user.id,
          passwordHash,
        })
        .execute();

      // Store the identity document
      await trx
        .insertInto("agentDocuments")
        .values({
          userId: user.id,
          documentType,
          documentData,
        })
        .execute();

      // Generate and set slug
      const slug = generateUserSlug(displayName, user.id);
      await trx
        .updateTable("users")
        .set({ slug })
        .where("id", "=", user.id)
        .execute();

      return { ...user, slug };
    });

    // Create a new session
    const sessionId = randomBytes(32).toString("hex");
    const now = new Date();
    const expiresAt = new Date(now.getTime() + SessionExpirationSeconds * 1000);

    await db
      .insertInto("sessions")
      .values({
        id: sessionId,
        userId: newUser.id,
        createdAt: now,
        lastAccessed: now,
        expiresAt,
      })
      .execute();

    // Create response with user data
    const response = new Response(
      superjson.stringify({
        user: {
          id: newUser.id,
          email: newUser.email,
          displayName: newUser.displayName,
          avatarUrl: newUser.avatarUrl,
          role: newUser.role as "agent",
        },
      }),
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    // Set session cookie
    await setServerSession(response, {
      id: sessionId,
      createdAt: now.getTime(),
      lastAccessed: now.getTime(),
    });

    // Fire-and-forget: send welcome and admin notification emails
    const welcomeEmail = getWelcomeAgentEmail(newUser.displayName);
    const adminEmail = getAdminNewAgentEmail(newUser.displayName, newUser.email);
    Promise.all([
      sendEmail(newUser.email, welcomeEmail.subject, welcomeEmail.html),
      sendEmail(ADMIN_EMAIL, adminEmail.subject, adminEmail.html),
    ]).catch((err) => {
      console.error("Failed to send agent registration emails:", err);
    });

    return response;
  } catch (error: unknown) {
    console.error("Agent registration error:", error);
    const errorMessage =
      error instanceof Error ? error.message : "L'inscription a échoué";
    return new Response(
      superjson.stringify({ message: errorMessage }),
      {
        status: 400,
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
  }
}