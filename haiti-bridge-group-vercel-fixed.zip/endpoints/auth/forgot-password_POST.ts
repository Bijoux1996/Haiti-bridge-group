import { schema, OutputType } from "./forgot-password_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { randomBytes } from "crypto";
import { sendEmail, getPasswordResetEmail } from "../../helpers/sendEmail";

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const { email } = schema.parse(json);

    const user = await db
      .selectFrom("users")
      .select(["id", "displayName", "role"])
      .where("email", "=", email)
      .executeTakeFirst();

    const successResponse: OutputType = {
      success: true,
      message: "Si un compte existe avec cet email, vous recevrez un lien de réinitialisation."
    };

    if (!user) {
      // Prevent user enumeration attacks — return generic response without revealing whether email exists
      console.log(`Forgot password: no account found for email "${email}". Returning generic response.`);
      return new Response(superjson.stringify(successResponse));
    }

    console.log(`Forgot password: account found for user id=${user.id}. Generating reset token.`);

    const token = randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour expiration

    await db
      .insertInto("passwordResetTokens")
      .values({
        token,
        userId: user.id,
        expiresAt,
      })
      .execute();

    console.log(`Forgot password: reset token created for user id=${user.id}, expires at ${expiresAt.toISOString()}.`);

    const resetLink = user.role === "admin"
      ? `https://haitibridgegroup.com/admin/reset-password?token=${token}`
      : `https://haitibridgegroup.com/reset-password?token=${token}`;
    const { subject, html } = getPasswordResetEmail(user.displayName, resetLink);

    const emailResult = await sendEmail(email, subject, html);

    if (!emailResult.success) {
      console.error(`Forgot password: failed to send reset email to user id=${user.id}. Error: ${emailResult.error}`);
      throw new Error("Erreur lors de l'envoi de l'email de réinitialisation");
    }

    console.log(`Forgot password: reset email successfully sent to user id=${user.id}.`);

    return new Response(superjson.stringify(successResponse));
  } catch (error: unknown) {
    console.error("Forgot password error:", error);
    const msg = error instanceof Error ? error.message : "Erreur interne";
    return new Response(
      superjson.stringify({ error: msg }),
      { status: 400 }
    );
  }
}