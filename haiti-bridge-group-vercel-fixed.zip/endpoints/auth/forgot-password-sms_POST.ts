import { schema, OutputType } from "./forgot-password-sms_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { sendSMS } from "../../helpers/sendSMS";
import { randomInt } from "crypto";

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const { phone } = schema.parse(json);

    // Look for a user by phone
    const user = await db
      .selectFrom("users")
      .select(["id", "phone"])
      .where("phone", "=", phone)
      .executeTakeFirst();

    const successResponse: OutputType = {
      success: true,
      message: "Si un compte existe avec ce numéro, vous recevrez un code par SMS.",
    };

    if (!user) {
      // Prevent user enumeration by masking that the phone was not found
      console.log(`Forgot password SMS: no account found for phone "${phone}". Returning generic response.`);
      return new Response(superjson.stringify(successResponse));
    }

    console.log(`Forgot password SMS: account found for user id=${user.id}. Generating code.`);

    // Invalidate existing unused codes for this user
    await db
      .updateTable("smsResetCodes")
      .set({ usedAt: new Date() })
      .where("userId", "=", user.id)
      .where("usedAt", "is", null)
      .execute();

    // Generate a secure 6-digit verification code
    const code = randomInt(0, 1000000).toString().padStart(6, "0");
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // Expires in 10 minutes

    await db
      .insertInto("smsResetCodes")
      .values({
        code,
        phone,
        userId: user.id,
        expiresAt,
      })
      .execute();

    // Dispatch SMS via Twilio
    const message = `Votre code de réinitialisation Haiti Bridge Group: ${code}. Ce code expire dans 10 minutes.`;
    const smsResult = await sendSMS(phone, message);

    if (!smsResult.success) {
      console.error(`Forgot password SMS: failed to send SMS to user id=${user.id}. Error: ${smsResult.error}`);
      throw new Error("Erreur lors de l'envoi du SMS");
    }

    return new Response(superjson.stringify(successResponse));
  } catch (error: unknown) {
    console.error("Forgot password SMS error:", error);
    const msg = error instanceof Error ? error.message : "Erreur interne";
    return new Response(
      superjson.stringify({ error: msg }),
      { status: 400 }
    );
  }
}