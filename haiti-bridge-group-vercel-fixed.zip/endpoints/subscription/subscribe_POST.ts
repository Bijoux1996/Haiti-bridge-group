import { schema, OutputType } from "./subscribe_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";
import { sendEmail, getPaymentNotificationEmail } from "../../helpers/sendEmail";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    if (user.role !== "agent" && user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Accès refusé. Seuls les agents peuvent souscrire à un abonnement." }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const plan = await db
      .selectFrom("subscriptionPlans")
      .selectAll()
      .where("id", "=", input.planId)
      .where("isActive", "=", true)
      .executeTakeFirst();

    if (!plan) {
      return new Response(
        superjson.stringify({ error: "Le plan sélectionné est introuvable ou inactif." }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    const price = Number(plan.priceHtg);
    const isFree = isNaN(price) || price === 0;

    if (!isFree) {
      if (!input.paymentMethod || !input.paymentReference) {
        return new Response(
          superjson.stringify({ error: "La méthode de paiement et la référence sont requises pour les plans payants." }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
      }
    }

    const newSubId = await db.transaction().execute(async (trx) => {
      // Cancel previous active/pending subscriptions
      await trx
        .updateTable("userSubscriptions")
        .set({
          status: "cancelled",
          cancelledAt: new Date(),
        })
        .where("userId", "=", user.id)
        .where("status", "in", ["active", "pending"])
        .execute();

      const now = new Date();
      let expiresAt: Date | null = null;
      let startedAt: Date | null = null;
      let status: "active" | "pending" = "pending";

      if (isFree) {
        status = "active";
        startedAt = now;
        expiresAt = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000); // 1 year
      }

      const insertResult = await trx
        .insertInto("userSubscriptions")
        .values({
          userId: user.id,
          planId: plan.id,
          status,
          paymentMethod: isFree ? null : input.paymentMethod,
          paymentReference: isFree ? null : input.paymentReference,
          startedAt,
          expiresAt,
        })
        .returning("id")
        .executeTakeFirstOrThrow();

      return insertResult.id;
    });

    const newSubscription = await db
      .selectFrom("userSubscriptions")
      .selectAll()
      .where("id", "=", newSubId)
      .executeTakeFirstOrThrow();

    // Fire-and-forget: send payment notification email for paid plans
    if (!isFree && input.paymentMethod && input.paymentReference) {
      const userRecord = await db
        .selectFrom("users")
        .select(["email", "displayName"])
        .where("id", "=", user.id)
        .executeTakeFirst();

      if (userRecord) {
        const { subject, html } = getPaymentNotificationEmail(
          userRecord.displayName,
          plan.name,
          input.paymentMethod,
          input.paymentReference
        );
        sendEmail(userRecord.email, subject, html).catch((err) => {
          console.error("Failed to send payment notification email:", err);
        });
      }
    }

    const output: OutputType = {
      subscription: {
        ...newSubscription,
        plan,
      },
    };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Erreur interne du serveur" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}