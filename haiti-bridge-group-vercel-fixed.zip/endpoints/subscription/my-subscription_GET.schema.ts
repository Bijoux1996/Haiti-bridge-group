import { z } from "zod";
import superjson from "superjson";
import { Selectable } from "kysely";
import { SubscriptionPlans, UserSubscriptions } from "../../helpers/schema";

export const schema = z.object({});

export type InputType = z.infer<typeof schema>;

export type SubscriptionWithPlan = Selectable<UserSubscriptions> & {
  plan: Selectable<SubscriptionPlans>;
};

export type OutputType = {
  subscription: SubscriptionWithPlan | null;
};

export const getMySubscription = async (
  input?: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const url = new URL(`/_api/subscription/my-subscription`, typeof window !== "undefined" ? window.location.origin : "http://localhost");
  
  const result = await fetch(url.toString(), {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to fetch my subscription");
  }
  return superjson.parse<OutputType>(await result.text());
};