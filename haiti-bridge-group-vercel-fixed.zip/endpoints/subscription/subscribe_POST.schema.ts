import { z } from "zod";
import superjson from "superjson";
import { PaymentMethodArrayValues } from "../../helpers/schema";
import { SubscriptionWithPlan } from "./my-subscription_GET.schema";

export const schema = z.object({
  planId: z.number(),
  paymentMethod: z.enum(PaymentMethodArrayValues).optional(),
  paymentReference: z.string().optional(),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  subscription: SubscriptionWithPlan;
};

export const postSubscribe = async (
  body: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const result = await fetch(`/_api/subscription/subscribe`, {
    method: "POST",
    body: superjson.stringify(body),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to subscribe");
  }
  return superjson.parse<OutputType>(await result.text());
};