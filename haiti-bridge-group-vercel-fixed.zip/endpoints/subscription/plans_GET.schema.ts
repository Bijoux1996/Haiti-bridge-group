import { z } from "zod";
import superjson from "superjson";
import { Selectable } from "kysely";
import { SubscriptionPlans } from "../../helpers/schema";

export const schema = z.object({});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  plans: Selectable<SubscriptionPlans>[];
};

export const getSubscriptionPlans = async (
  input?: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const url = new URL(`/_api/subscription/plans`, typeof window !== "undefined" ? window.location.origin : "http://localhost");
  
  const result = await fetch(url.toString(), {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to fetch subscription plans");
  }
  return superjson.parse<OutputType>(await result.text());
};