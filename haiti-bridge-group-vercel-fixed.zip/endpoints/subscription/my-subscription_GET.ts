import { schema, OutputType } from "./my-subscription_GET.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    const subscription = await db
      .selectFrom("userSubscriptions")
      .selectAll()
      .where("userId", "=", user.id)
      .where("status", "=", "active")
      .orderBy("createdAt", "desc")
      .executeTakeFirst();

    if (!subscription) {
      return new Response(
        superjson.stringify({ subscription: null } satisfies OutputType),
        { headers: { "Content-Type": "application/json" } }
      );
    }

    const plan = await db
      .selectFrom("subscriptionPlans")
      .selectAll()
      .where("id", "=", subscription.planId)
      .executeTakeFirst();

    if (!plan) {
      return new Response(
        superjson.stringify({ subscription: null } satisfies OutputType),
        { headers: { "Content-Type": "application/json" } }
      );
    }

    const output: OutputType = {
      subscription: {
        ...subscription,
        plan,
      },
    };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Erreur interne du serveur" }),
      { status: 401, headers: { "Content-Type": "application/json" } }
    );
  }
}