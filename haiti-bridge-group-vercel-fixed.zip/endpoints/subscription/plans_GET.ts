import { schema, OutputType } from "./plans_GET.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";

export async function handle(request: Request) {
  try {
    const plans = await db
      .selectFrom("subscriptionPlans")
      .selectAll()
      .where("isActive", "=", true)
      .orderBy("sortOrder", "asc")
      .execute();

    const output: OutputType = { plans };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Erreur interne du serveur" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
}