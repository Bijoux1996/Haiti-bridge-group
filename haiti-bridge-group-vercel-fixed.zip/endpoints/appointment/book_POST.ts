import { schema, OutputType } from "./book_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    // Look up the property to get the agent_id
    const property = await db
      .selectFrom("properties")
      .select("agentId")
      .where("id", "=", input.propertyId)
      .executeTakeFirst();

    if (!property) {
      return new Response(superjson.stringify({ error: "Property not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }

    if (!property.agentId) {
      return new Response(superjson.stringify({ error: "Property does not have an assigned agent" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    // Insert into appointments table
    const result = await db
      .insertInto("appointments")
      .values({
        propertyId: input.propertyId,
        agentId: property.agentId,
        clientName: input.clientName,
        clientEmail: input.clientEmail || null,
        clientPhone: input.clientPhone,
        preferredDate: new Date(input.preferredDate),
        preferredTime: input.preferredTime,
        message: input.message || null,
        status: "pending",
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning("id")
      .executeTakeFirstOrThrow();

    const output: OutputType = {
      success: true,
      appointmentId: result.id,
    };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}