import { schema, OutputType } from "./update_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    if (user.role !== "agent" && user.role !== "admin") {
      return new Response(superjson.stringify({ error: "Unauthorized access" }), {
        status: 403,
        headers: { "Content-Type": "application/json" },
      });
    }

    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    // Find the appointment
    const appointment = await db
      .selectFrom("appointments")
      .select(["id", "agentId"])
      .where("id", "=", input.appointmentId)
      .executeTakeFirst();

    if (!appointment) {
      return new Response(superjson.stringify({ error: "Appointment not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }

    // Verify ownership if agent
    if (user.role === "agent" && appointment.agentId !== user.id) {
      return new Response(superjson.stringify({ error: "Forbidden: You don't own this appointment" }), {
        status: 403,
        headers: { "Content-Type": "application/json" },
      });
    }

    // Update status
    await db
      .updateTable("appointments")
      .set({
        status: input.status,
        updatedAt: new Date(),
      })
      .where("id", "=", input.appointmentId)
      .execute();

    const output: OutputType = {
      success: true,
    };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}