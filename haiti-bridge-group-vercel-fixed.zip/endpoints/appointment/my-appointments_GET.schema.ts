import { z } from "zod";
import superjson from "superjson";
import { AppointmentStatusArrayValues } from "../../helpers/schema";

export const schema = z.object({
  page: z.number().optional().default(1),
  limit: z.number().optional().default(20),
  status: z.enum(AppointmentStatusArrayValues).optional(),
});

export type InputType = z.infer<typeof schema>;

export type AppointmentOutputItem = {
  id: number;
  propertyId: number;
  propertyTitle: string;
  propertyCity: string;
  clientName: string;
  clientEmail: string | null;
  clientPhone: string;
  preferredDate: Date | string;
  preferredTime: string;
  message: string | null;
  status: string;
  createdAt: Date | string | null;
};

export type OutputType = {
  appointments: AppointmentOutputItem[];
  totalCount: number;
  page: number;
  totalPages: number;
};

export const getMyAppointments = async (
  input: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const url = new URL(
    `/_api/appointment/my-appointments`,
    typeof window !== "undefined" ? window.location.origin : "http://localhost"
  );
  url.searchParams.set("json", superjson.stringify(input));

  const result = await fetch(url.toString(), {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to fetch appointments");
  }
  return superjson.parse<OutputType>(await result.text());
};