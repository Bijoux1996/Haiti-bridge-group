import { z } from "zod";
import superjson from "superjson";

export const schema = z.object({
  propertyId: z.number(),
  clientName: z.string().min(2, "Name must be at least 2 characters"),
  clientEmail: z.string().email("Invalid email format").optional().or(z.literal("")),
  clientPhone: z.string().min(8, "Phone must be at least 8 characters"),
  preferredDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Format must be YYYY-MM-DD"),
  preferredTime: z.string().regex(/^\d{2}:\d{2}$/, "Format must be HH:MM"),
  message: z.string().max(500, "Message cannot exceed 500 characters").optional(),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  success: boolean;
  appointmentId: number;
};

export const postBookAppointment = async (
  body: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/appointment/book`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};