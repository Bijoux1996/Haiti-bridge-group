import { z } from "zod";
import superjson from "superjson";
import { AppointmentStatusArrayValues } from "../../helpers/schema";

export const schema = z.object({
  appointmentId: z.number(),
  status: z.enum(AppointmentStatusArrayValues).refine((val) => val !== "pending", {
    message: "Cannot revert to pending status",
  }),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  success: boolean;
};

export const postUpdateAppointment = async (
  body: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const validatedInput = schema.parse(body);
  const result = await fetch(`/_api/appointment/update`, {
    method: "POST",
    body: superjson.stringify(validatedInput),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error);
  }
  return superjson.parse<OutputType>(await result.text());
};