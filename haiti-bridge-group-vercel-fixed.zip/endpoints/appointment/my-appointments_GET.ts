import { schema, OutputType } from "./my-appointments_GET.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    if (user.role !== "agent" && user.role !== "admin") {
      return new Response(superjson.stringify({ error: "Unauthorized access" }), {
        status: 403,
        headers: { "Content-Type": "application/json" },
      });
    }

    const url = new URL(request.url);
    const jsonString = url.searchParams.get("json");
    const json = jsonString ? superjson.parse(jsonString) : {};
    const input = schema.parse(json);

    let query = db
      .selectFrom("appointments")
      .innerJoin("properties", "properties.id", "appointments.propertyId");

    let countQuery = db.selectFrom("appointments");

    // Filter by agent if not admin
    if (user.role === "agent") {
      query = query.where("appointments.agentId", "=", user.id);
      countQuery = countQuery.where("appointments.agentId", "=", user.id);
    }

    if (input.status) {
      query = query.where("appointments.status", "=", input.status);
      countQuery = countQuery.where("appointments.status", "=", input.status);
    }

    const countResult = await countQuery
      .select((eb) => eb.fn.count<string | number>("id").as("count"))
      .executeTakeFirst();

    const totalCount = Number(countResult?.count || 0);

    const appointments = await query
      .select([
        "appointments.id",
        "appointments.propertyId",
        "properties.title as propertyTitle",
        "properties.city as propertyCity",
        "appointments.clientName",
        "appointments.clientEmail",
        "appointments.clientPhone",
        "appointments.preferredDate",
        "appointments.preferredTime",
        "appointments.message",
        "appointments.status",
        "appointments.createdAt",
      ])
      .orderBy("appointments.preferredDate", "asc")
      .orderBy("appointments.preferredTime", "asc")
      .limit(input.limit)
      .offset((input.page - 1) * input.limit)
      .execute();

    const output: OutputType = {
      appointments,
      totalCount,
      page: input.page,
      totalPages: Math.ceil(totalCount / input.limit),
    };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}