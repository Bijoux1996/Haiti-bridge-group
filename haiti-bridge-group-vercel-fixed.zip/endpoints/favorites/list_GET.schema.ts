import { z } from "zod";
import superjson from "superjson";
import { PropertyListOutputItem } from "../property/list_GET.schema";

export const schema = z.object({
  page: z.number().optional().default(1),
  limit: z.number().optional().default(20),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  properties: PropertyListOutputItem[];
  totalCount: number;
  page: number;
  totalPages: number;
};

export const getFavoritesList = async (
  input: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const url = new URL(
    `/_api/favorites/list`,
    typeof window !== "undefined" ? window.location.origin : "http://localhost"
  );
  url.searchParams.set("json", superjson.stringify(input));

  const result = await fetch(url.toString(), {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to fetch favorites");
  }
  return superjson.parse<OutputType>(await result.text());
};