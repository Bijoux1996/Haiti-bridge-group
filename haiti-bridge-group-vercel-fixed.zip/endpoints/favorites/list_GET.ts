import { schema, OutputType } from "./list_GET.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";
import { sql } from "kysely";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    const url = new URL(request.url);
    const jsonString = url.searchParams.get("json");
    const json = jsonString ? superjson.parse(jsonString) : {};
    const input = schema.parse(json);

    const countResult = await db
      .selectFrom("favorites")
      .where("userId", "=", user.id)
      .select((eb) => eb.fn.count<string | number>("id").as("count"))
      .executeTakeFirst();

    const totalCount = Number(countResult?.count || 0);

    const properties = await db
      .selectFrom("favorites")
      .innerJoin("properties", "properties.id", "favorites.propertyId")
      .leftJoin("propertyImages", (join) =>
        join
          .onRef("propertyImages.propertyId", "=", "properties.id")
          .on("propertyImages.isPrimary", "=", sql`true`)
      )
      .leftJoin("users", "users.id", "properties.agentId")
      .where("favorites.userId", "=", user.id)
      .select([
        "properties.id",
        "properties.title",
        "properties.price",
        "properties.category",
        "properties.bedrooms",
        "properties.bathrooms",
        "properties.areaSqft",
        "properties.city",
        "properties.address",
        "properties.isFeatured",
        "properties.phone",
        "properties.whatsapp",
        "properties.createdAt",
        "propertyImages.imageUrl as primaryImageUrl",
        "users.displayName as agentName",
      ])
      .orderBy("favorites.createdAt", "desc")
      .limit(input.limit)
      .offset((input.page - 1) * input.limit)
      .execute();

    const output: OutputType = {
      properties,
      totalCount,
      page: input.page,
      totalPages: Math.ceil(totalCount / input.limit),
    };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({
        error: error instanceof Error ? error.message : "Internal server error",
      }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}