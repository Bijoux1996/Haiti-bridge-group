import { schema, OutputType } from "./toggle_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const existingFavorite = await db
      .selectFrom("favorites")
      .select("id")
      .where("userId", "=", user.id)
      .where("propertyId", "=", input.propertyId)
      .executeTakeFirst();

    if (existingFavorite) {
      await db
        .deleteFrom("favorites")
        .where("id", "=", existingFavorite.id)
        .execute();

      return new Response(
        superjson.stringify({ isFavorited: false } satisfies OutputType),
        { headers: { "Content-Type": "application/json" } }
      );
    } else {
      await db
        .insertInto("favorites")
        .values({
          userId: user.id,
          propertyId: input.propertyId,
        })
        .execute();

      return new Response(
        superjson.stringify({ isFavorited: true } satisfies OutputType),
        { headers: { "Content-Type": "application/json" } }
      );
    }
  } catch (error) {
    return new Response(
      superjson.stringify({
        error: error instanceof Error ? error.message : "Internal server error",
      }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}