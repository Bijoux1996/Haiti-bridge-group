import { schema, OutputType } from "./check_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    if (input.propertyIds.length === 0) {
      return new Response(
        superjson.stringify({ favoritedIds: [] } satisfies OutputType),
        {
          headers: { "Content-Type": "application/json" },
        }
      );
    }

    const favorites = await db
      .selectFrom("favorites")
      .select("propertyId")
      .where("userId", "=", user.id)
      .where("propertyId", "in", input.propertyIds)
      .execute();

    const favoritedIds = favorites.map((f) => f.propertyId);

    return new Response(
      superjson.stringify({ favoritedIds } satisfies OutputType),
      {
        headers: { "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    return new Response(
      superjson.stringify({
        error: error instanceof Error ? error.message : "Internal server error",
      }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}