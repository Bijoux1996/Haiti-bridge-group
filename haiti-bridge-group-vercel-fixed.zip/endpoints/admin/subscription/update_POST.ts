import { schema, OutputType } from "./update_POST.schema";
import superjson from "superjson";
import { db } from "../../../helpers/db";
import { getServerUserSession } from "../../../helpers/getServerUserSession";
import { Updateable } from "kysely";
import { UserSubscriptions } from "../../../helpers/schema";
import {
  sendEmail,
  getSubscriptionActivatedEmail,
  getSubscriptionDeactivatedEmail,
} from "../../../helpers/sendEmail";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    if (user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Accès refusé. Réservé aux administrateurs." }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const now = new Date();
    const updateData: Updateable<UserSubscriptions> = {};
    let expiresAtForEmail: Date | null = null;

    if (input.action === "approve") {
      expiresAtForEmail = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      updateData.status = "active";
      updateData.startedAt = now;
      updateData.expiresAt = expiresAtForEmail;
    } else if (input.action === "reject") {
      updateData.status = "cancelled";
      updateData.cancelledAt = now;
    } else if (input.action === "activate") {
      expiresAtForEmail = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
      updateData.status = "active";
      updateData.startedAt = now;
      updateData.expiresAt = expiresAtForEmail;
    } else if (input.action === "deactivate") {
      updateData.status = "cancelled";
      updateData.cancelledAt = now;
    } else if (input.action === "change_plan") {
      if (input.newPlanId === undefined) {
        return new Response(
          superjson.stringify({ error: "newPlanId est requis pour l'action change_plan." }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
      }

      // Validate that the plan exists and is active
      const plan = await db
        .selectFrom("subscriptionPlans")
        .select("id")
        .where("id", "=", input.newPlanId)
        .where("isActive", "=", true)
        .executeTakeFirst();

      if (!plan) {
        return new Response(
          superjson.stringify({ error: "Plan d'abonnement introuvable ou inactif." }),
          { status: 404, headers: { "Content-Type": "application/json" } }
        );
      }

      updateData.planId = input.newPlanId;
    }

    const result = await db
      .updateTable("userSubscriptions")
      .set(updateData)
      .where("id", "=", input.subscriptionId)
      .executeTakeFirst();

    if (Number(result.numUpdatedRows) === 0) {
      return new Response(
        superjson.stringify({ error: "Abonnement introuvable." }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    console.log(`Admin ${user.id} performed action "${input.action}" on subscription ${input.subscriptionId}`);

    // Fire-and-forget: send email notification for approve/activate/reject/deactivate actions
    const shouldNotify =
      input.action === "approve" ||
      input.action === "activate" ||
      input.action === "reject" ||
      input.action === "deactivate";

    if (shouldNotify) {
      // Fetch the subscription's user and plan info asynchronously
      Promise.all([
        db
          .selectFrom("userSubscriptions")
          .innerJoin("users", "userSubscriptions.userId", "users.id")
          .innerJoin("subscriptionPlans", "userSubscriptions.planId", "subscriptionPlans.id")
          .select([
            "users.email",
            "users.displayName",
            "subscriptionPlans.name as planName",
          ])
          .where("userSubscriptions.id", "=", input.subscriptionId)
          .executeTakeFirst(),
      ])
        .then(([subInfo]) => {
          if (!subInfo) {
            console.warn(`Could not find subscription info for email notification (subscriptionId=${input.subscriptionId})`);
            return;
          }

          const isActivating =
            input.action === "approve" || input.action === "activate";

          if (isActivating && expiresAtForEmail) {
            const { subject, html } = getSubscriptionActivatedEmail(
              subInfo.displayName,
              subInfo.planName,
              expiresAtForEmail
            );
            return sendEmail(subInfo.email, subject, html);
          } else if (!isActivating) {
            const { subject, html } = getSubscriptionDeactivatedEmail(
              subInfo.displayName,
              subInfo.planName
            );
            return sendEmail(subInfo.email, subject, html);
          }
        })
        .catch((err) => {
          console.error(`Failed to send subscription ${input.action} email for subscription ${input.subscriptionId}:`, err);
        });
    }

    return new Response(superjson.stringify({ success: true } satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error in admin subscription update:", error);
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}