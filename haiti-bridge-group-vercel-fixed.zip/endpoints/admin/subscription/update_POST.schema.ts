import { z } from "zod";
import superjson from "superjson";

export const schema = z.object({
  subscriptionId: z.number(),
  action: z.enum(["approve", "reject", "activate", "deactivate", "change_plan"]),
  newPlanId: z.number().optional(),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  success: boolean;
};

export const postAdminUpdateSubscription = async (
  body: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const result = await fetch(`/_api/admin/subscription/update`, {
    method: "POST",
    body: superjson.stringify(body),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to update subscription");
  }
  return superjson.parse<OutputType>(await result.text());
};