import { schema, OutputType } from "./update_POST.schema";
import superjson from "superjson";
import { db } from "../../../helpers/db";
import { getServerUserSession } from "../../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    if (user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Accès refusé. Réservé aux administrateurs." }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const updateData: Partial<typeof input> = {};
    if (input.isFeatured !== undefined) updateData.isFeatured = input.isFeatured;

    if (Object.keys(updateData).length === 0) {
      return new Response(
        superjson.stringify({ error: "Aucun champ à mettre à jour." }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    const result = await db
      .updateTable("properties")
      .set(updateData)
      .where("id", "=", input.propertyId)
      .executeTakeFirst();

    if (Number(result.numUpdatedRows) === 0) {
      return new Response(
        superjson.stringify({ error: "Propriété introuvable." }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    const output: OutputType = { success: true };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}