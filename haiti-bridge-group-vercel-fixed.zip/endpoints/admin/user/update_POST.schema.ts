import { z } from "zod";
import superjson from "superjson";
import { UserRoleArrayValues, VerificationStatusArrayValues } from "../../../helpers/schema";

export const schema = z.object({
  userId: z.number(),
  role: z.enum(UserRoleArrayValues).optional(),
  verificationStatus: z.enum(VerificationStatusArrayValues).optional(),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  user: {
    id: number;
    email: string;
    displayName: string;
    role: string;
    verificationStatus: string | null;
  };
};

export const postAdminUpdateUser = async (
  body: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const result = await fetch(`/_api/admin/user/update`, {
    method: "POST",
    body: superjson.stringify(body),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to update user");
  }
  return superjson.parse<OutputType>(await result.text());
};