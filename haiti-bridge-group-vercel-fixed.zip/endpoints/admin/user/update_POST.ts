import { schema, OutputType } from "./update_POST.schema";
import superjson from "superjson";
import { db } from "../../../helpers/db";
import { getServerUserSession } from "../../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    if (user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Accès refusé. Réservé aux administrateurs." }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const updateData: Partial<typeof input> = {};
    if (input.role !== undefined) updateData.role = input.role;
    if (input.verificationStatus !== undefined) updateData.verificationStatus = input.verificationStatus;

    if (Object.keys(updateData).length === 0) {
      return new Response(
        superjson.stringify({ error: "Aucun champ à mettre à jour." }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    const updatedUser = await db
      .updateTable("users")
      .set(updateData)
      .where("id", "=", input.userId)
      .returning(["id", "email", "displayName", "role", "verificationStatus"])
      .executeTakeFirst();

    if (!updatedUser) {
      return new Response(
        superjson.stringify({ error: "Utilisateur introuvable." }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    const output: OutputType = { user: updatedUser };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}