import { z } from "zod";
import superjson from "superjson";
import { ReportStatusArrayValues } from "../../../helpers/schema";

export const schema = z.object({
  reportId: z.number(),
  status: z.enum(ReportStatusArrayValues),
  adminNotes: z.string().optional(),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  success: boolean;
};

export const postAdminReportUpdate = async (
  body: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const result = await fetch(`/_api/admin/report/update`, {
    method: "POST",
    body: superjson.stringify(body),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Échec de la mise à jour du signalement");
  }
  return superjson.parse<OutputType>(await result.text());
};