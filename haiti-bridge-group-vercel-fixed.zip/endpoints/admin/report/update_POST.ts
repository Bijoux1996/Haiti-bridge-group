import { schema, OutputType } from "./update_POST.schema";
import superjson from "superjson";
import { db } from "../../../helpers/db";
import { getServerUserSession } from "../../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);

    if (user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Accès refusé. Réservé aux administrateurs." }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    const result = await db
      .updateTable("propertyReports")
      .set({
        status: input.status,
        adminNotes: input.adminNotes,
        updatedAt: new Date(),
      })
      .where("id", "=", input.reportId)
      .executeTakeFirst();

    if (Number(result.numUpdatedRows) === 0) {
      return new Response(
        superjson.stringify({ error: "Signalement introuvable." }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    const output: OutputType = { success: true };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}