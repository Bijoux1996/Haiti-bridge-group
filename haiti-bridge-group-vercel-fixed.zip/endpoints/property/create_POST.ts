import { schema, OutputType } from "./create_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);
    
    if (user.role !== "agent" && user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Forbidden: Only agents and admins can create listings" }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const bodyText = await request.text();
    const input = schema.parse(superjson.parse(bodyText));

    const result = await db.transaction().execute(async (trx) => {
      const now = new Date();
      const property = await trx.insertInto("properties")
        .values({
          agentId: user.id,
          title: input.title,
          description: input.description || null,
          price: input.price.toString(),
          category: input.category,
          bedrooms: input.bedrooms ?? null,
          bathrooms: input.bathrooms ?? null,
          areaSqft: input.areaSqft ?? null,
          city: input.city,
          address: input.address || null,
          phone: input.phone || null,
          whatsapp: input.whatsapp || null,
          createdAt: now,
          updatedAt: now,
        })
        .returningAll()
        .executeTakeFirstOrThrow();

      let images: any[] = [];
      if (input.imageUrls.length > 0) {
        images = await trx.insertInto("propertyImages")
          .values(
            input.imageUrls.map((url, index) => ({
              propertyId: property.id,
              imageUrl: url,
              isPrimary: index === 0,
              createdAt: now,
            }))
          )
          .returningAll()
          .execute();
      }

      return {
        ...property,
        images,
      };
    });

    return new Response(
      superjson.stringify({ property: result } satisfies OutputType),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}