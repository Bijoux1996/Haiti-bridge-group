import { z } from "zod";
import superjson from "superjson";
import { PropertyCategoryArrayValues } from "../../helpers/schema";

export const schema = z.object({
  category: z.enum(PropertyCategoryArrayValues).optional(),
  city: z.string().optional(),
  minPrice: z.number().optional(),
  maxPrice: z.number().optional(),
  bedrooms: z.number().optional(),
  search: z.string().optional(),
  featured: z.boolean().optional(),
  page: z.number().optional().default(1),
  limit: z.number().optional().default(12),
});

export type InputType = z.infer<typeof schema>;

export type PropertyListOutputItem = {
  id: number;
  title: string;
  price: string | number;
  category: string;
  bedrooms: number | null;
  bathrooms: number | null;
  areaSqft: number | null;
  city: string;
  address: string | null;
  isFeatured: boolean | null;
  phone: string | null;
  whatsapp: string | null;
  createdAt: Date | string | null;
  primaryImageUrl: string | null;
  agentName: string | null;
};

export type OutputType = {
  properties: PropertyListOutputItem[];
  totalCount: number;
  page: number;
  totalPages: number;
};

export const getPropertyList = async (
  input: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const url = new URL(`/_api/property/list`, typeof window !== "undefined" ? window.location.origin : "http://localhost");
  url.searchParams.set("json", superjson.stringify(input));
  
  const result = await fetch(url.toString(), {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to fetch properties");
  }
  return superjson.parse<OutputType>(await result.text());
};