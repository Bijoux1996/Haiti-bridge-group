import { schema, OutputType } from "./list_GET.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { sql } from "kysely";

export async function handle(request: Request) {
  try {
    const url = new URL(request.url);
    const jsonString = url.searchParams.get("json");
    const json = jsonString ? superjson.parse(jsonString) : {};
    const input = schema.parse(json);

    let query = db.selectFrom("properties")
      .leftJoin("propertyImages", (join) => 
        join.onRef("propertyImages.propertyId", "=", "properties.id")
          .on("propertyImages.isPrimary", "=", sql`true`)
      )
      .leftJoin("users", "users.id", "properties.agentId");

    let countQuery = db.selectFrom("properties");

    if (input.category) {
      query = query.where("properties.category", "=", input.category);
      countQuery = countQuery.where("properties.category", "=", input.category);
    }

    if (input.city) {
      query = query.where("properties.city", "ilike", `%${input.city}%`);
      countQuery = countQuery.where("properties.city", "ilike", `%${input.city}%`);
    }

    if (input.minPrice !== undefined) {
      query = query.where("properties.price", ">=", input.minPrice.toString());
      countQuery = countQuery.where("properties.price", ">=", input.minPrice.toString());
    }

    if (input.maxPrice !== undefined) {
      query = query.where("properties.price", "<=", input.maxPrice.toString());
      countQuery = countQuery.where("properties.price", "<=", input.maxPrice.toString());
    }

    if (input.bedrooms !== undefined) {
      query = query.where("properties.bedrooms", ">=", input.bedrooms);
      countQuery = countQuery.where("properties.bedrooms", ">=", input.bedrooms);
    }

    if (input.featured !== undefined) {
      query = query.where("properties.isFeatured", "=", input.featured);
      countQuery = countQuery.where("properties.isFeatured", "=", input.featured);
    }

    if (input.search) {
      const searchTerms = `%${input.search}%`;
      query = query.where((eb) => 
        eb.or([
          eb("properties.title", "ilike", searchTerms),
          eb("properties.description", "ilike", searchTerms)
        ])
      );
      countQuery = countQuery.where((eb) => 
        eb.or([
          eb("properties.title", "ilike", searchTerms),
          eb("properties.description", "ilike", searchTerms)
        ])
      );
    }

    const countResult = await countQuery
      .select((eb) => eb.fn.count<string | number>("id").as("count"))
      .executeTakeFirst();
      
    const totalCount = Number(countResult?.count || 0);

    const properties = await query
      .select([
        "properties.id",
        "properties.title",
        "properties.price",
        "properties.category",
        "properties.bedrooms",
        "properties.bathrooms",
        "properties.areaSqft",
        "properties.city",
        "properties.address",
        "properties.isFeatured",
        "properties.phone",
        "properties.whatsapp",
        "properties.createdAt",
        "propertyImages.imageUrl as primaryImageUrl",
        "users.displayName as agentName"
      ])
      .orderBy("properties.createdAt", "desc")
      .limit(input.limit)
      .offset((input.page - 1) * input.limit)
      .execute();

    const output: OutputType = {
      properties,
      totalCount,
      page: input.page,
      totalPages: Math.ceil(totalCount / input.limit),
    };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}