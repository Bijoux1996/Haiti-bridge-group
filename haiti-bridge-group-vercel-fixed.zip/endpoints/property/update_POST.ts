import { schema, OutputType } from "./update_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);
    
    if (user.role !== "agent" && user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Forbidden: Only agents and admins can update listings" }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const bodyText = await request.text();
    const input = schema.parse(superjson.parse(bodyText));

    const existingProperty = await db.selectFrom("properties")
      .selectAll()
      .where("id", "=", input.id)
      .executeTakeFirst();

    if (!existingProperty) {
      return new Response(
        superjson.stringify({ error: "Property not found" }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    if (existingProperty.agentId !== user.id && user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Forbidden: You are not the owner of this property" }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const result = await db.transaction().execute(async (trx) => {
      const updates: any = { updatedAt: new Date() };
      
      if (input.title !== undefined) updates.title = input.title;
      if (input.description !== undefined) updates.description = input.description;
      if (input.price !== undefined) updates.price = input.price.toString();
      if (input.category !== undefined) updates.category = input.category;
      if (input.bedrooms !== undefined) updates.bedrooms = input.bedrooms;
      if (input.bathrooms !== undefined) updates.bathrooms = input.bathrooms;
      if (input.areaSqft !== undefined) updates.areaSqft = input.areaSqft;
      if (input.city !== undefined) updates.city = input.city;
      if (input.address !== undefined) updates.address = input.address;
      if (input.phone !== undefined) updates.phone = input.phone;
      if (input.whatsapp !== undefined) updates.whatsapp = input.whatsapp;

      const property = await trx.updateTable("properties")
        .set(updates)
        .where("id", "=", input.id)
        .returningAll()
        .executeTakeFirstOrThrow();

      let images: any[] = [];
      if (input.imageUrls) {
        await trx.deleteFrom("propertyImages")
          .where("propertyId", "=", input.id)
          .execute();

        if (input.imageUrls.length > 0) {
          images = await trx.insertInto("propertyImages")
            .values(
              input.imageUrls.map((url, index) => ({
                propertyId: input.id,
                imageUrl: url,
                isPrimary: index === 0,
                createdAt: new Date(),
              }))
            )
            .returningAll()
            .execute();
        }
      } else {
        images = await trx.selectFrom("propertyImages")
          .selectAll()
          .where("propertyId", "=", input.id)
          .orderBy("isPrimary", "desc")
          .orderBy("createdAt", "asc")
          .execute();
      }

      return {
        ...property,
        images,
      };
    });

    return new Response(
      superjson.stringify({ property: result } satisfies OutputType),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}