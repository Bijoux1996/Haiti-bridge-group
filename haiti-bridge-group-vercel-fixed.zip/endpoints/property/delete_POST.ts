import { schema, OutputType } from "./delete_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);
    
    if (user.role !== "agent" && user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Forbidden: Only agents and admins can delete listings" }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const bodyText = await request.text();
    const input = schema.parse(superjson.parse(bodyText));

    const existingProperty = await db.selectFrom("properties")
      .select(["id", "agentId"])
      .where("id", "=", input.id)
      .executeTakeFirst();

    if (!existingProperty) {
      return new Response(
        superjson.stringify({ error: "Property not found" }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    if (existingProperty.agentId !== user.id && user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Forbidden: You are not the owner of this property" }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    await db.transaction().execute(async (trx) => {
      await trx.deleteFrom("propertyImages")
        .where("propertyId", "=", input.id)
        .execute();

      await trx.deleteFrom("properties")
        .where("id", "=", input.id)
        .execute();
    });

    return new Response(
      superjson.stringify({ success: true } satisfies OutputType),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}