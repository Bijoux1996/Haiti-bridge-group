import { schema, PropertyDetailOutput } from "./detail_GET.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";

export async function handle(request: Request) {
  try {
    const url = new URL(request.url);
    const jsonString = url.searchParams.get("json");
    if (!jsonString) {
      throw new Error("Missing required json query parameter");
    }
    
    const input = schema.parse(superjson.parse(jsonString));

    const property = await db.selectFrom("properties")
      .selectAll("properties")
      .where("properties.id", "=", input.id)
      .executeTakeFirst();

    if (!property) {
      return new Response(
        superjson.stringify({ error: "Property not found" }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    const images = await db.selectFrom("propertyImages")
      .select(["id", "imageUrl", "isPrimary"])
      .where("propertyId", "=", property.id)
      .orderBy("isPrimary", "desc")
      .orderBy("createdAt", "asc")
      .execute();

    let agent: PropertyDetailOutput["agent"] = null;
    if (property.agentId) {
      const user = await db.selectFrom("users")
        .select(["displayName", "email", "avatarUrl"])
        .where("id", "=", property.agentId)
        .executeTakeFirst();

      if (user) {
        const reviewStats = await db.selectFrom("reviews")
          .select((eb) => [
            eb.fn.count<number>("id").as("reviewCount"),
            eb.fn.avg<number>("rating").as("averageRating"),
          ])
          .where("agentId", "=", property.agentId)
          .executeTakeFirst();

        const reviewCount = reviewStats ? Number(reviewStats.reviewCount) : 0;
        const rawAvg = reviewStats ? reviewStats.averageRating : null;
        const averageRating =
          rawAvg !== null && rawAvg !== undefined && reviewCount > 0
            ? Math.round(Number(rawAvg) * 10) / 10
            : null;

        console.log(
          `Agent ${property.agentId} review stats: count=${reviewCount}, avg=${averageRating}`
        );

        agent = {
          ...user,
          reviewCount,
          averageRating,
        };
      }
    }

    const output: PropertyDetailOutput = {
      ...property,
      agent,
      images,
    };

    return new Response(superjson.stringify(output satisfies PropertyDetailOutput), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}