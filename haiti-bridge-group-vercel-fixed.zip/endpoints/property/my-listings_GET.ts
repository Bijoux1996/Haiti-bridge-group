import { schema, OutputType } from "./my-listings_GET.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const { user } = await getServerUserSession(request);
    
    if (user.role !== "agent" && user.role !== "admin") {
      return new Response(
        superjson.stringify({ error: "Forbidden: Only agents and admins can view their listings" }),
        { status: 403, headers: { "Content-Type": "application/json" } }
      );
    }

    const properties = await db.selectFrom("properties")
      .selectAll()
      .where("agentId", "=", user.id)
      .orderBy("createdAt", "desc")
      .execute();

    if (properties.length === 0) {
      return new Response(
        superjson.stringify({ properties: [] } satisfies OutputType),
        { headers: { "Content-Type": "application/json" } }
      );
    }

    const propertyIds = properties.map((p) => p.id);
    const images = await db.selectFrom("propertyImages")
      .selectAll()
      .where("propertyId", "in", propertyIds)
      .orderBy("isPrimary", "desc")
      .orderBy("createdAt", "asc")
      .execute();

    const propertiesWithImages = properties.map((prop) => ({
      ...prop,
      images: images.filter((img) => img.propertyId === prop.id),
    }));

    return new Response(
      superjson.stringify({ properties: propertiesWithImages } satisfies OutputType),
      { headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Internal server error" }),
      { status: 401, headers: { "Content-Type": "application/json" } }
    );
  }
}