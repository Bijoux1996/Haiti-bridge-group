import { z } from "zod";
import superjson from "superjson";
import { Selectable } from "kysely";
import { Properties, PropertyImages } from "../../helpers/schema";

export const schema = z.object({});

export type InputType = z.infer<typeof schema>;

export type PropertyWithImages = Selectable<Properties> & {
  images: Selectable<PropertyImages>[];
};

export type OutputType = {
  properties: PropertyWithImages[];
};

export const getMyListings = async (
  input?: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const url = new URL(`/_api/property/my-listings`, typeof window !== "undefined" ? window.location.origin : "http://localhost");
  
  const result = await fetch(url.toString(), {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to fetch my listings");
  }
  return superjson.parse<OutputType>(await result.text());
};