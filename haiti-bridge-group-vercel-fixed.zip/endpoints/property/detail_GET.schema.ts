import { z } from "zod";
import superjson from "superjson";
import { Selectable } from "kysely";
import { Properties } from "../../helpers/schema";

export const schema = z.object({
  id: z.number(),
});

export type InputType = z.infer<typeof schema>;

export type PropertyDetailOutput = Selectable<Properties> & {
  agent: {
    displayName: string;
    email: string;
    avatarUrl: string | null;
    reviewCount: number;
    averageRating: number | null;
  } | null;
  images: {
    id: number;
    imageUrl: string;
    isPrimary: boolean | null;
  }[];
};

export const getPropertyDetail = async (
  input: InputType,
  init?: RequestInit
): Promise<PropertyDetailOutput> => {
  const url = new URL(`/_api/property/detail`, typeof window !== "undefined" ? window.location.origin : "http://localhost");
  url.searchParams.set("json", superjson.stringify(input));
  
  const result = await fetch(url.toString(), {
    method: "GET",
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to fetch property details");
  }
  return superjson.parse<PropertyDetailOutput>(await result.text());
};