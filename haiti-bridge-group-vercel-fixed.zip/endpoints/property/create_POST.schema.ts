import { z } from "zod";
import superjson from "superjson";
import { Selectable } from "kysely";
import { Properties, PropertyImages, PropertyCategoryArrayValues } from "../../helpers/schema";

export const schema = z.object({
  title: z.string(),
  description: z.string().optional(),
  price: z.number(),
  category: z.enum(PropertyCategoryArrayValues),
  bedrooms: z.number().optional(),
  bathrooms: z.number().optional(),
  areaSqft: z.number().optional(),
  city: z.string(),
  address: z.string().optional(),
  phone: z.string().optional(),
  whatsapp: z.string().optional(),
  imageUrls: z.array(z.string()),
});

export type InputType = z.infer<typeof schema>;

export type PropertyWithImages = Selectable<Properties> & {
  images: Selectable<PropertyImages>[];
};

export type OutputType = {
  property: PropertyWithImages;
};

export const postCreateProperty = async (
  input: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const result = await fetch(`/_api/property/create`, {
    method: "POST",
    body: superjson.stringify(input),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  
  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Failed to create property");
  }
  return superjson.parse<OutputType>(await result.text());
};