import { z } from "zod";
import superjson from "superjson";
import { ReportReasonArrayValues } from "../../helpers/schema";

export const schema = z.object({
  propertyId: z.number(),
  reason: z.enum(ReportReasonArrayValues),
  description: z.string().min(10, "La description doit contenir au moins 10 caractères.").max(2000, "La description est trop longue."),
  reporterEmail: z.string().email("Adresse email invalide.").optional(),
});

export type InputType = z.infer<typeof schema>;

export type OutputType = {
  success: boolean;
  reportId: number;
};

export const postReportCreate = async (
  body: InputType,
  init?: RequestInit
): Promise<OutputType> => {
  const result = await fetch(`/_api/report/create`, {
    method: "POST",
    body: superjson.stringify(body),
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (!result.ok) {
    const errorObject = superjson.parse<{ error: string }>(await result.text());
    throw new Error(errorObject.error || "Une erreur est survenue");
  }
  
  return superjson.parse<OutputType>(await result.text());
};