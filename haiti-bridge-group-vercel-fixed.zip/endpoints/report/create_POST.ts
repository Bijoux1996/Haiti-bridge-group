import { schema, OutputType } from "./create_POST.schema";
import superjson from "superjson";
import { db } from "../../helpers/db";
import { getServerUserSession } from "../../helpers/getServerUserSession";

export async function handle(request: Request) {
  try {
    const json = superjson.parse(await request.text());
    const input = schema.parse(json);

    let reporterId: number | null = null;
    let reporterEmail: string | null = input.reporterEmail || null;

    try {
      const { user } = await getServerUserSession(request);
      reporterId = user.id;
      reporterEmail = user.email; // Fallback to user's email if needed
    } catch (e) {
      // Not authenticated, which is fine, but we must have an email
      if (!reporterEmail) {
        return new Response(
          superjson.stringify({ error: "L'adresse email est requise si vous n'êtes pas connecté." }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
      }
    }

    // Check if property exists
    const property = await db
      .selectFrom("properties")
      .select("id")
      .where("id", "=", input.propertyId)
      .executeTakeFirst();

    if (!property) {
      return new Response(
        superjson.stringify({ error: "Annonce introuvable." }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    // Check for duplicate pending reports by this user/email
    let duplicateQuery = db
      .selectFrom("propertyReports")
      .select("id")
      .where("propertyId", "=", input.propertyId)
      .where("status", "=", "pending");

    if (reporterId) {
      duplicateQuery = duplicateQuery.where((eb) =>
        eb.or([
          eb("reporterId", "=", reporterId),
          eb("reporterEmail", "=", reporterEmail ?? ""),
        ])
      );
    } else if (reporterEmail) {
      duplicateQuery = duplicateQuery.where("reporterEmail", "=", reporterEmail);
    }

    const existingReport = await duplicateQuery.executeTakeFirst();

    if (existingReport) {
      return new Response(
        superjson.stringify({ error: "Vous avez déjà signalé cette annonce." }),
        { status: 409, headers: { "Content-Type": "application/json" } }
      );
    }

    // Create report
    const newReport = await db
      .insertInto("propertyReports")
      .values({
        propertyId: input.propertyId,
        reason: input.reason,
        description: input.description,
        reporterId,
        reporterEmail,
        status: "pending",
      })
      .returning("id")
      .executeTakeFirstOrThrow();

    const output: OutputType = {
      success: true,
      reportId: newReport.id,
    };

    return new Response(superjson.stringify(output satisfies OutputType), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(
      superjson.stringify({ error: error instanceof Error ? error.message : "Erreur interne" }),
      { status: 400, headers: { "Content-Type": "application/json" } }
    );
  }
}